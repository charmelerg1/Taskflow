package dao;

import database.DBConnection;
import model.Task;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TaskDAO {

    public boolean addTask(Task task) {
        String sql = "INSERT INTO tasks "
                + "(project_id, task_name, description, assigned_to, "
                + "priority, deadline, task_status) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            if (task.getProjectId() <= 0) {
                ps.setNull(1, Types.INTEGER);
            } else {
                ps.setInt(1, task.getProjectId());
            }

            ps.setString(2, task.getTaskName());
            ps.setString(3, task.getDescription());

            if (task.getAssignedTo() <= 0) {
                ps.setNull(4, Types.INTEGER);
            } else {
                ps.setInt(4, task.getAssignedTo());
            }

            ps.setString(5, task.getPriority());
            ps.setDate(6, Date.valueOf(task.getDeadline()));
            ps.setString(7, task.getStatus());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error adding task: " + e.getMessage());
            return false;
        }
    }

    public Task getTaskById(int taskId) {
        String sql = "SELECT * FROM tasks WHERE task_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, taskId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapTask(rs);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error getting task: " + e.getMessage());
        }

        return null;
    }

    public List<Task> getAllTasks() {
        List<Task> tasks = new ArrayList<>();
        String sql = "SELECT * FROM tasks ORDER BY task_id DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                tasks.add(mapTask(rs));
            }

        } catch (SQLException e) {
            System.err.println("Error loading tasks: " + e.getMessage());
        }

        return tasks;
    }

    public List<Task> getTasksByProject(int projectId) {
        List<Task> tasks = new ArrayList<>();
        String sql = "SELECT * FROM tasks WHERE project_id = ? "
                + "ORDER BY task_id DESC";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, projectId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    tasks.add(mapTask(rs));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error loading project tasks: " + e.getMessage());
        }

        return tasks;
    }

    public boolean updateTask(Task task) {
        String sql = "UPDATE tasks SET project_id = ?, task_name = ?, "
                + "description = ?, assigned_to = ?, priority = ?, "
                + "deadline = ?, task_status = ? WHERE task_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            if (task.getProjectId() <= 0) {
                ps.setNull(1, Types.INTEGER);
            } else {
                ps.setInt(1, task.getProjectId());
            }

            ps.setString(2, task.getTaskName());
            ps.setString(3, task.getDescription());

            if (task.getAssignedTo() <= 0) {
                ps.setNull(4, Types.INTEGER);
            } else {
                ps.setInt(4, task.getAssignedTo());
            }

            ps.setString(5, task.getPriority());
            ps.setDate(6, Date.valueOf(task.getDeadline()));
            ps.setString(7, task.getStatus());
            ps.setInt(8, task.getTaskId());

            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error updating task: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteTask(int taskId) {
        String sql = "DELETE FROM tasks WHERE task_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, taskId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error deleting task: " + e.getMessage());
            return false;
        }
    }

    private Task mapTask(ResultSet rs) throws SQLException {
        Date sqlDate = rs.getDate("deadline");

        Task task = new Task();
        task.setTaskId(rs.getInt("task_id"));
        task.setTaskName(rs.getString("task_name"));
        task.setDescription(rs.getString("description"));
        task.setProjectId(rs.getInt("project_id"));
        task.setAssignedTo(rs.getInt("assigned_to"));
        task.setPriority(rs.getString("priority"));
        task.setDeadline(
                sqlDate == null ? null : sqlDate.toLocalDate()
        );
        task.setStatus(rs.getString("task_status"));

        return task;
    }
}