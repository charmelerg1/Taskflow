/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package gui;

import database.DBConnection;

import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class MainFormNew1 extends javax.swing.JPanel {
    
    private model.User loggedInUser;
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(MainFormNew1.class.getName());

    
    /**
     * Creates new form MainFormNew
     */
   




// Tracks which sidebar button is selected

    // TASKFLOW sidebar colors
    private final java.awt.Color NAVY =
            new java.awt.Color(11, 45, 92);

    private final java.awt.Color HOVER_BLUE =
            new java.awt.Color(36, 75, 122);

    private javax.swing.JButton activeSidebarButton;

    private java.awt.LayoutManager dashboardLayout;
private java.awt.Component[] dashboardComponents;
   


public MainFormNew1() {
    this(null);
}

public MainFormNew1(model.User user) {
    this.loggedInUser = user;  // Save the logged-in user first
System.out.println("Logged-in username: " + loggedInUser.getUsername());
System.out.println("Logged-in role: [" + loggedInUser.getRole() + "]");
System.out.println("Is student: " + isStudent());
    initComponents();

    if (loggedInUser == null) {
        JOptionPane.showMessageDialog(
            this,
            "User information is missing. Please log in again.",
            "Login Error",
            JOptionPane.ERROR_MESSAGE
        );
        return;
    }

    JOptionPane.showMessageDialog(
        this,
        "Username: " + loggedInUser.getUsername()
        + "\nRole: [" + loggedInUser.getRole() + "]"
    );

    // Keep the rest of your existing dashboard setup code here.

    
    txtSearch.addActionListener(e -> searchAll());
    
dashboardLayout = contentPanel.getLayout();
dashboardComponents = contentPanel.getComponents();
    this.loggedInUser = user;

    if (loggedInUser != null) {
        lblAdmin.setText(loggedInUser.getFullName());
    }

    fixDashboardPanelSizes();

    sidebarPanel.setBackground(NAVY);
    contentPanel.setBackground(new java.awt.Color(234, 240, 247));

    styleSidebarButtons();
    addSidebarHoverEffects();
    configureRoleBasedAccess();

    loadProjectOverview();
    loadDashboardCounts();
    loadRecentTasks();
    loadUpcomingDeadlines();
    applyDashboardLayout();
    
    
    // Load the profile photo after the UI is displayed.
    javax.swing.SwingUtilities.invokeLater(this::updateProfileIcon);

    btnDashboard.addActionListener(
        e -> setActiveButton(btnDashboard)
    );
    btnProjects.addActionListener(
        e -> setActiveButton(btnProjects)
    );
    btnTasks.addActionListener(
        e -> setActiveButton(btnTasks)
    );
    btnTeam.addActionListener(
        e -> setActiveButton(btnTeam)
    );
    btnReports.addActionListener(
        e -> setActiveButton(btnReports)
    );
    btnDatabase.addActionListener(
        e -> setActiveButton(btnDatabase)
    );

    lblViewAll1.setCursor(
        new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR)
    );

    lblViewAll1.addMouseListener(
        new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                showAllTasks();
            }
        }
    );

    lblViewAll.setCursor(
        new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR)
    );

    lblViewAll.addMouseListener(
        new java.awt.event.MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                showAllProjects();
            }
        }
    );
}

    private void searchAll() {

    String keyword = txtSearch.getText().trim();

    if (keyword.isEmpty()
            || keyword.equalsIgnoreCase(
                    "Search projects, tasks, or members...")) {
        JOptionPane.showMessageDialog(
                this,
                "Please enter something to search.",
                "Search",
                JOptionPane.INFORMATION_MESSAGE
        );
        return;
    }

    String sql =
        "SELECT 'Project' AS category, " +
        "project_id AS record_id, " +
        "project_name AS item_name, " +
        "description AS details, " +
        "project_status AS extra_info, " +
        "CAST(deadline AS CHAR) AS due_date " +
        "FROM projects " +
        "WHERE project_name LIKE ? " +
        "OR description LIKE ? OR project_status LIKE ? " +

        "UNION ALL " +

        "SELECT 'Task' AS category, " +
        "task_id AS record_id, " +
        "task_name AS item_name, " +
        "description AS details, " +
        "CONCAT('Priority: ', COALESCE(priority, ''), " +
        "' | Status: ', COALESCE(task_status, '')) AS extra_info, " +
        "CAST(deadline AS CHAR) AS due_date " +
        "FROM tasks " +
        "WHERE task_name LIKE ? " +
        "OR description LIKE ? OR priority LIKE ? " +
        "OR task_status LIKE ? " +

        "UNION ALL " +

        "SELECT 'Member' AS category, " +
        "user_id AS record_id, " +
        "CONCAT(first_name, ' ', last_name) AS item_name, " +
        "email AS details, " +
        "role AS extra_info, " +
        "'' AS due_date " +
        "FROM users " +
        "WHERE first_name LIKE ? " +
        "OR last_name LIKE ? OR username LIKE ?";

    DefaultTableModel tableModel = new DefaultTableModel(
        new String[]{
            "Category", "ID", "Name",
            "Details", "Status / Role", "Deadline"
        },
        0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    String searchValue = "%" + keyword + "%";

    try (Connection con = database.DBConnection.getConnection()) {

        if (con == null) {
            JOptionPane.showMessageDialog(
                    this, "Database connection failed.",
                    "Database Error", JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        try (PreparedStatement ps = con.prepareStatement(sql)) {

            for (int i = 1; i <= 10; i++) {
                ps.setString(i, searchValue);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    tableModel.addRow(new Object[]{
                        rs.getString("category"),
                        rs.getInt("record_id"),
                        rs.getString("item_name"),
                        rs.getString("details"),
                        rs.getString("extra_info"),
                        rs.getString("due_date")
                    });
                }
            }
        }

        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(
                    this,
                    "No matching projects, tasks, or members found.",
                    "No Results",
                    JOptionPane.INFORMATION_MESSAGE
            );
            return;
        }

        JTable resultsTable = new JTable(tableModel);
        resultsTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        resultsTable.setRowHeight(25);
        resultsTable.setFillsViewportHeight(true);

        int[] columnWidths = {90, 50, 180, 220, 180, 110};

        for (int i = 0; i < columnWidths.length; i++) {
            resultsTable.getColumnModel()
                    .getColumn(i)
                    .setPreferredWidth(columnWidths[i]);
        }

        JScrollPane scrollPane = new JScrollPane(resultsTable);
        scrollPane.setPreferredSize(new Dimension(850, 350));

        JOptionPane.showMessageDialog(
                this,
                scrollPane,
                "Search Results: " + keyword,
                JOptionPane.PLAIN_MESSAGE
        );

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(
                this,
                "Search failed: " + ex.getMessage(),
                "Database Error",
                JOptionPane.ERROR_MESSAGE
        );
        ex.printStackTrace();
    }
}

   
private void fixDashboardPanelSizes() {
    contentPanel.revalidate();
    contentPanel.repaint();
}
    

    private void styleSidebarButtons() {
        javax.swing.JButton[] buttons = {
            btnDashboard, btnProjects, btnTasks,
            btnTeam, btnReports, btnDatabase,
        };

        for (javax.swing.JButton button : buttons) {
            button.setUI(new RoundedSidebarButtonUI());
            button.setOpaque(false);
            button.setContentAreaFilled(false);
            button.setBorderPainted(false);
            button.setFocusPainted(false);
            button.setRolloverEnabled(false);
            button.setHorizontalAlignment(
                    javax.swing.SwingConstants.LEFT);
            button.setBorder(
                    javax.swing.BorderFactory.createEmptyBorder(
                            10, 15, 10, 15));
            button.setBackground(NAVY);
            button.setForeground(java.awt.Color.WHITE);
            button.setCursor(new java.awt.Cursor(
                    java.awt.Cursor.HAND_CURSOR));
        }
    }

    private static class RoundedSidebarButtonUI
            extends javax.swing.plaf.basic.BasicButtonUI {

        @Override
        public void paint(
                java.awt.Graphics g,
                javax.swing.JComponent c) {

            javax.swing.JButton button =
                    (javax.swing.JButton) c;

            java.awt.Graphics2D g2 =
                    (java.awt.Graphics2D) g.create();

            g2.setRenderingHint(
                    java.awt.RenderingHints.KEY_ANTIALIASING,
                    java.awt.RenderingHints.VALUE_ANTIALIAS_ON);

            g2.setColor(button.getBackground());
            g2.fillRoundRect(
                    0, 0,
                    button.getWidth(),
                    button.getHeight(),
                    14, 14);

            g2.dispose();
            super.paint(g, c);
        }
    }

    private void addSidebarHoverEffects() {
        javax.swing.JButton[] buttons = {
            btnDashboard, btnProjects, btnTasks,
            btnTeam, btnReports, btnDatabase,
        };

        for (javax.swing.JButton button : buttons) {
            button.addMouseListener(
                    new java.awt.event.MouseAdapter() {
                @Override
                public void mouseEntered(
                        java.awt.event.MouseEvent e) {
                    button.setBackground(HOVER_BLUE);
                    button.repaint();
                }

                @Override
                public void mouseExited(
                        java.awt.event.MouseEvent e) {
                    if (button == activeSidebarButton) {
                        button.setBackground(HOVER_BLUE);
                    } else {
                        button.setBackground(NAVY);
                    }
                    button.repaint();
                }
            });
        }
    }

    private void setActiveButton(
            javax.swing.JButton activeButton) {

        javax.swing.JButton[] buttons = {
            btnDashboard, btnProjects, btnTasks,
            btnTeam, btnReports, btnDatabase
        };

        activeSidebarButton = activeButton;

        for (javax.swing.JButton button : buttons) {
            button.setBackground(NAVY);
            button.setForeground(java.awt.Color.WHITE);
            button.repaint();
        }

        activeButton.setBackground(HOVER_BLUE);
        activeButton.setForeground(java.awt.Color.WHITE);
        activeButton.repaint();
    }
    

private void loadDashboardCounts() {

    boolean student = isStudent();
    int userId = (loggedInUser != null)
            ? loggedInUser.getUserId() : -1;

    String[] queries;

    if (student) {
        queries = new String[] {
            "SELECT COUNT(*) FROM projects WHERE user_id = ?",
            "SELECT COUNT(*) FROM users WHERE user_id = ?",
            "SELECT COUNT(*) FROM tasks t " +
                "WHERE LOWER(t.task_status) = 'completed' " +
                "AND t.assigned_to = ?",
            "SELECT COUNT(*) FROM tasks t " +
                "WHERE LOWER(t.task_status) = 'pending' " +
                "AND t.assigned_to = ?"
        };
    } else {
        queries = new String[] {
            "SELECT COUNT(*) FROM projects",
            "SELECT COUNT(*) FROM users",
            "SELECT COUNT(*) FROM tasks " +
                "WHERE LOWER(task_status) = 'completed'",
            "SELECT COUNT(*) FROM tasks " +
                "WHERE LOWER(task_status) = 'pending'"
        };
    }

    javax.swing.JLabel[] labels = {
        lblProjectsCount1,
        lblUsersCount,
        lblTasksCount,
        lblCompletedCount
    };

    try (Connection conn = DBConnection.getConnection()) {

        if (conn == null) {
            JOptionPane.showMessageDialog(
                this, "Database connection failed."
            );
            return;
        }

        for (int i = 0; i < queries.length; i++) {

            try (PreparedStatement ps =
                    conn.prepareStatement(queries[i])) {

                if (student) {
                    ps.setInt(1, userId);
                }

                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        labels[i].setText(
                            String.valueOf(rs.getInt(1))
                        );
                    }
                }
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Error loading dashboard: " + e.getMessage()
        );
    }
}



private void loadProjectOverview() {
    String sql =
        "SELECT p.project_name, p.project_status AS project_status, " +
        "COUNT(t.task_id) AS total_tasks, " +
        "COALESCE(SUM(CASE " +
        "WHEN LOWER(TRIM(COALESCE(t.task_status, ''))) = 'completed' " +
        "THEN 1 ELSE 0 END), 0) AS completed_tasks " +
        "FROM projects p " +
        "LEFT JOIN tasks t ON p.project_id = t.project_id " +
        "GROUP BY p.project_id, p.project_name, p.project_status, p.deadline " +
        "ORDER BY p.deadline ASC " +
        "LIMIT 1";

    try (Connection conn = DBConnection.getConnection()) {
        if (conn == null) {
            return;
        }

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            if (rs.next()) {
                String projectName = rs.getString("project_name");
                String status = rs.getString("project_status");

                int totalTasks = rs.getInt("total_tasks");
                int completedTasks = rs.getInt("completed_tasks");

                int progress = totalTasks == 0
                    ? 0
                    : (completedTasks * 100) / totalTasks;

                // Project name
                jLabel6.setText(
                    projectName == null ? "Untitled Project" : projectName
                );

                // Progress percentage
                lblProgressValue.setText(progress + "%");

                // Progress bar
                jProgressBar1.setMinimum(0);
                jProgressBar1.setMaximum(100);
                jProgressBar1.setValue(progress);
                jProgressBar1.setForeground(
                    new Color(39, 101, 181)
                );
                jProgressBar1.setBackground(
                    new Color(225, 239, 255)
                );
                jProgressBar1.setVisible(true);
                jProgressBar1.setStringPainted(false);
                jProgressBar1.setPreferredSize(new Dimension(200, 15));
                jProgressBar1.setMinimumSize(new Dimension(200, 15));
                jProgressBar1.setOpaque(true);
                jProgressBar1.setBorderPainted(true);
                jProgressBar1.revalidate();
                jProgressBar1.repaint();

                // Completed tasks count
                jLabel5.setText(String.valueOf(completedTasks));

                // Project status
                jLabel7.setText(
                    status == null || status.isBlank()
                        ? "Not Started"
                        : status
                );

            } else {
                // No projects found
                jLabel6.setText("No projects yet");
                lblProgressValue.setText("0%");

                jProgressBar1.setMinimum(0);
                jProgressBar1.setMaximum(100);
                jProgressBar1.setValue(0);
                jProgressBar1.setVisible(true);
                
                jProgressBar1.setPreferredSize(new Dimension(200, 15));
                jProgressBar1.setMinimumSize(new Dimension(200, 15));
                jProgressBar1.setOpaque(true);
                jProgressBar1.setBorderPainted(true);
                jProgressBar1.setForeground(new Color(39, 101, 181));
                jProgressBar1.setBackground(new Color(225, 239, 255));
                jProgressBar1.setVisible(true);
                jProgressBar1.revalidate();
                jProgressBar1.repaint();

                jLabel5.setText("0");
                jLabel7.setText("Not Started");
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Unable to load Project Overview: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );

        e.printStackTrace();
    }
}


private void loadRecentTasks() {
    String sql =
        "SELECT t.task_name, p.project_name, t.priority, " +
        "t.deadline, t.task_status " +
        "FROM tasks t " +
        "LEFT JOIN projects p ON t.project_id = p.project_id " +
        "WHERE t.assigned_to = ? " +
        "ORDER BY t.task_id DESC " +
        "LIMIT 1";

    try (Connection conn = DBConnection.getConnection()) {

        if (conn == null) {
            return;
        }

        try (PreparedStatement ps = conn.prepareStatement(sql)) {

            // FIX: Set the logged-in user's ID
            ps.setInt(1, loggedInUser.getUserId());

            try (ResultSet rs = ps.executeQuery()) {

                if (rs.next()) {
                    String taskName = rs.getString("task_name");
                    String projectName = rs.getString("project_name");
                    String priority = rs.getString("priority");
                    java.sql.Date deadline = rs.getDate("deadline");
                    String status = rs.getString("task_status");

                    lbltaskname1.setText(
                        taskName == null ? "Untitled Task" : taskName
                    );

                    lbltaskname2.setText(
                        projectName == null ? "No Project" : projectName
                    );

                    jLabel8.setText(
                        priority == null ? "—" : priority
                    );

                    jLabel9.setText(
                        deadline == null
                            ? "No deadline"
                            : deadline.toLocalDate().format(
                                java.time.format.DateTimeFormatter.ofPattern(
                                    "MMM dd, yyyy"
                                )
                            )
                    );

                    jLabel10.setText(
                        status == null ? "Pending" : status
                    );

                } else {
                    lbltaskname1.setText("No tasks yet");
                    lbltaskname2.setText("—");
                    jLabel8.setText("—");
                    jLabel9.setText("—");
                    jLabel10.setText("—");
                }
            }
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Unable to load Recent Tasks: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
        e.printStackTrace();
    }
}

private void showAllTasks() {
    String sql =
        "SELECT t.task_name, p.project_name, " +
        "t.priority, t.deadline, t.task_status " +
        "FROM tasks t " +
        "LEFT JOIN projects p ON t.project_id = p.project_id " +
        "ORDER BY t.task_id DESC";

    String[] columns = {
        "Task Name", "Project", "Priority", "Deadline", "Status"
    };

    DefaultTableModel model = new DefaultTableModel(columns, 0);

    try (Connection conn = DBConnection.getConnection()) {
        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Database connection failed.");
            return;
        }

        try (PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                java.sql.Date deadline = rs.getDate("deadline");

                model.addRow(new Object[] {
                    rs.getString("task_name"),
                    rs.getString("project_name"),
                    rs.getString("priority"),
                    deadline == null ? "No deadline" : deadline.toString(),
                    rs.getString("task_status")
                });
            }
        }

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(new java.awt.Dimension(750, 300));

        JOptionPane.showMessageDialog(
            this,
            scrollPane,
            "All Tasks",
            JOptionPane.PLAIN_MESSAGE
        );

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Unable to load tasks: " + e.getMessage()
        );
    }
}

private void showAllProjects() {
    String sql =
        "SELECT project_id, project_name, description, " +
        "start_date, deadline, project_status " +
        "FROM projects ORDER BY project_id DESC";

    String[] columns = {
        "ID", "Project Name", "Description",
        "Start Date", "Deadline", "Project Status"
    };

    DefaultTableModel tableModel =
        new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(
                int row, int column
            ) {
                return false;
            }
        };

    try (Connection conn = DBConnection.getConnection()) {
        if (conn == null) {
            JOptionPane.showMessageDialog(
                this, "Database connection failed."
            );
            return;
        }

        try (PreparedStatement ps =
                 conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("project_id"),
                    rs.getString("project_name"),
                    rs.getString("description"),
                    rs.getString("start_date"),
                    rs.getString("deadline"),
                    rs.getString("project_status")
                });
            }
        }

        if (tableModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(
                this,
                "No projects found.",
                "All Projects",
                JOptionPane.INFORMATION_MESSAGE
            );
            return;
        }

        JTable table = new JTable(tableModel);
        table.setRowHeight(25);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

        int[] widths = {50, 160, 220, 110, 110, 110};

        for (int i = 0; i < widths.length; i++) {
            table.getColumnModel()
                .getColumn(i)
                .setPreferredWidth(widths[i]);
        }

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setPreferredSize(
            new Dimension(800, 350)
        );

        JOptionPane.showMessageDialog(
            this,
            scrollPane,
            "All Projects",
            JOptionPane.PLAIN_MESSAGE
        );

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(
            this,
            "Unable to load projects: " + e.getMessage(),
            "Database Error",
            JOptionPane.ERROR_MESSAGE
        );
    }
}



private void loadUpcomingDeadlines() {
    DeadlinesListPanel1.removeAll();
    DeadlinesListPanel1.setLayout(
        new BoxLayout(DeadlinesListPanel1, BoxLayout.Y_AXIS)
    );
    DeadlinesListPanel1.setBackground(Color.WHITE);

    String sql =
        "SELECT t.task_name, p.project_name, t.deadline, " +
        "t.task_status AS status, t.priority " +
        "FROM tasks t " +
        "LEFT JOIN projects p ON t.project_id = p.project_id " +
        "WHERE t.deadline IS NOT NULL " +
        "AND t.deadline >= CURDATE() " +
        "AND LOWER(TRIM(COALESCE(t.task_status, ''))) <> 'completed' " +
        "ORDER BY t.deadline ASC LIMIT 20";

    boolean hasTasks = false;

    try (Connection conn = DBConnection.getConnection()) {
        if (conn == null) {
            DeadlinesListPanel1.add(
                createDeadlineMessage(
                    "Unable to connect to the database."
                )
            );
        } else {
            try (PreparedStatement ps = conn.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {

                while (rs.next()) {
                    hasTasks = true;

                    String taskName = rs.getString("task_name");
                    String projectName = rs.getString("project_name");
                    String status = rs.getString("status");
                    String priority = rs.getString("priority");
                    java.sql.Date deadline = rs.getDate("deadline");

                    JPanel taskRow = new JPanel(
                        new BorderLayout(12, 0)
                    );
                    taskRow.setBackground(Color.WHITE);
                    taskRow.setBorder(
                        BorderFactory.createEmptyBorder(10, 10, 10, 10)
                    );
                    taskRow.setMaximumSize(
                        new Dimension(Integer.MAX_VALUE, 100)
                    );
                    taskRow.setAlignmentX(Component.LEFT_ALIGNMENT);

                    // Date box
                    JPanel dateBox = new JPanel();
                    dateBox.setLayout(
                        new BoxLayout(dateBox, BoxLayout.Y_AXIS)
                    );
                    dateBox.setBackground(new Color(225, 239, 255));
                    dateBox.setPreferredSize(new Dimension(70, 75));
                    dateBox.setMinimumSize(new Dimension(70, 75));

                    JLabel monthLabel = new JLabel(
                        deadline.toLocalDate()
                            .format(DateTimeFormatter.ofPattern("MMM"))
                            .toUpperCase()
                    );
                    monthLabel.setFont(
                        new Font("Segoe UI", Font.BOLD, 13)
                    );
                    monthLabel.setForeground(new Color(23, 59, 108));
                    monthLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

                    JLabel dayLabel = new JLabel(
                        String.valueOf(deadline.toLocalDate().getDayOfMonth())
                    );
                    dayLabel.setFont(
                        new Font("Segoe UI", Font.BOLD, 25)
                    );
                    dayLabel.setForeground(new Color(11, 45, 92));
                    dayLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

                    dateBox.add(Box.createVerticalGlue());
                    dateBox.add(monthLabel);
                    dateBox.add(Box.createVerticalStrut(3));
                    dateBox.add(dayLabel);
                    dateBox.add(Box.createVerticalGlue());

                    // Task details
                    JPanel detailsPanel = new JPanel();
                    detailsPanel.setLayout(
                        new BoxLayout(detailsPanel, BoxLayout.Y_AXIS)
                    );
                    detailsPanel.setBackground(Color.WHITE);

                    JLabel projectLabel = new JLabel(
                        projectName == null || projectName.isBlank()
                            ? "No Project" : projectName
                    );
                    projectLabel.setFont(
                        new Font("Segoe UI", Font.BOLD, 14)
                    );
                    projectLabel.setForeground(new Color(23, 59, 108));

                    JLabel taskLabel = new JLabel(
                        taskName == null || taskName.isBlank()
                            ? "Untitled Task" : taskName
                    );
                    taskLabel.setFont(
                        new Font("Segoe UI", Font.BOLD, 12)
                    );
                    taskLabel.setForeground(new Color(71, 85, 105));

                    JLabel statusLabel = new JLabel(
                        (status == null || status.isBlank()
                            ? "Pending" : status)
                        + "  |  "
                        + (priority == null || priority.isBlank()
                            ? "No priority" : priority)
                    );
                    statusLabel.setFont(
                        new Font("Segoe UI", Font.PLAIN, 12)
                    );
                    statusLabel.setForeground(new Color(39, 101, 181));

                    detailsPanel.add(projectLabel);
                    detailsPanel.add(Box.createVerticalStrut(5));
                    detailsPanel.add(taskLabel);
                    detailsPanel.add(Box.createVerticalStrut(8));
                    detailsPanel.add(statusLabel);

                    taskRow.add(dateBox, BorderLayout.WEST);
                    taskRow.add(detailsPanel, BorderLayout.CENTER);

                    // Add task row and horizontal separator
                    DeadlinesListPanel1.add(taskRow);

                    JSeparator separator =
                        new JSeparator(SwingConstants.HORIZONTAL);
                    separator.setAlignmentX(Component.LEFT_ALIGNMENT);
                    separator.setMaximumSize(
                        new Dimension(Integer.MAX_VALUE, 1)
                    );

                    DeadlinesListPanel1.add(separator);
                }
            }

            if (!hasTasks) {
                DeadlinesListPanel1.add(
                    createDeadlineMessage("No upcoming deadlines.")
                );
            }
        }

    } catch (SQLException e) {
    DeadlinesListPanel1.removeAll();

    DeadlinesListPanel1.add(
        createDeadlineMessage(
            "Unable to load upcoming deadlines."
        )
    );

    JOptionPane.showMessageDialog(
        this,
        "Unable to load upcoming deadlines:\n" + e.getMessage(),
        "Database Error",
        JOptionPane.ERROR_MESSAGE
    );

    e.printStackTrace();
  }
    
}

private JLabel createDeadlineMessage(String message) {
    JLabel label = new JLabel(message);

    label.setFont(
        new Font("Segoe UI", Font.PLAIN, 13)
    );
    label.setForeground(
        new Color(100, 116, 139)
    );
    label.setBorder(
        BorderFactory.createEmptyBorder(15, 10, 10, 10)
    );
    label.setAlignmentX(Component.LEFT_ALIGNMENT);

    return label;
}



private void showProfileMenu() {
    JPopupMenu profileMenu = new JPopupMenu();

    JPanel panel = new JPanel(new BorderLayout(10, 8));
    panel.setBorder(
        BorderFactory.createEmptyBorder(12, 14, 12, 14)
    );
    panel.setBackground(Color.WHITE);
    panel.setPreferredSize(new Dimension(230, 155));

    JLabel name = new JLabel(
        loggedInUser != null
            ? loggedInUser.getFullName()
            : "User"
    );
    name.setFont(new Font("Segoe UI", Font.BOLD, 15));
    name.setForeground(new Color(23, 59, 108));

    JLabel username = new JLabel(
        loggedInUser != null
            ? "@" + loggedInUser.getUsername()
            : "Not signed in"
    );
    username.setFont(new Font("Segoe UI", Font.PLAIN, 12));
    username.setForeground(Color.GRAY);

    JPanel info = new JPanel(new GridLayout(2, 1, 0, 4));
    info.setOpaque(false);
    info.add(name);
    info.add(username);

    JButton profileButton = new JButton("My Profile");

    profileButton.addActionListener(e -> {
        profileMenu.setVisible(false);

        if (loggedInUser == null) {
            JOptionPane.showMessageDialog(
                this,
                "No user is currently logged in.",
                "My Profile",
                JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        EditProfileFormNew editForm =
            new EditProfileFormNew(loggedInUser);

        editForm.addWindowListener(
            new java.awt.event.WindowAdapter() {
                @Override
                public void windowClosed(
                    java.awt.event.WindowEvent e
                ) {
                    lblAdmin.setText(
                        loggedInUser.getFullName()
                    );

                    updateProfileIcon();
                    revalidate();
                    repaint();
                }
            }
        );

        editForm.setLocationRelativeTo(this);
        editForm.setVisible(true);
    });

    JButton logoutButton = new JButton("Log Out");
    logoutButton.setForeground(new Color(180, 35, 24));

    logoutButton.addActionListener(e -> {
        profileMenu.setVisible(false);

        int choice = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to log out?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION
        );

        if (choice == JOptionPane.YES_OPTION) {
            Window window =
                SwingUtilities.getWindowAncestor(this);

            if (window != null) {
                window.dispose();
            }

            new LoginForm().setVisible(true);
        }
    });

    JPanel buttons = new JPanel(new GridLayout(2, 1, 0, 6));
    buttons.setOpaque(false);
    buttons.add(profileButton);
    buttons.add(logoutButton);

    JPanel top = new JPanel(new BorderLayout());
    top.setOpaque(false);
    top.add(info, BorderLayout.CENTER);

    panel.add(top, BorderLayout.NORTH);
    panel.add(buttons, BorderLayout.CENTER);

    profileMenu.add(panel);
    profileMenu.show(lblProfile, 0, lblProfile.getHeight());
}

private void showNotifications() {
    javax.swing.JPopupMenu menu = new javax.swing.JPopupMenu();

    javax.swing.JMenuItem title =
            new javax.swing.JMenuItem("Upcoming Task Deadlines");
    title.setEnabled(false);
    menu.add(title);
    menu.addSeparator();

    String sql =
        "SELECT t.task_name, p.project_name, t.deadline, t.priority " +
        "FROM tasks t " +
        "LEFT JOIN projects p ON t.project_id = p.project_id " +
        "WHERE t.deadline >= CURDATE() " +
        "AND t.task_status <> 'Completed' " +
        "ORDER BY t.deadline ASC LIMIT 10";

    try (java.sql.Connection conn =
                 database.DBConnection.getConnection()) {

        if (conn == null) {
            throw new java.sql.SQLException("Database connection failed.");
        }

        try (java.sql.PreparedStatement ps = conn.prepareStatement(sql);
             java.sql.ResultSet rs = ps.executeQuery()) {

            boolean found = false;

            while (rs.next()) {
                found = true;

                String taskName = rs.getString("task_name");
                String projectName = rs.getString("project_name");
                java.sql.Date deadline = rs.getDate("deadline");
                String priority = rs.getString("priority");

                javax.swing.JMenuItem item = new javax.swing.JMenuItem(
                    taskName + " | "
                    + (projectName == null ? "No project" : projectName)
                    + " | Due: " + deadline
                    + " | " + priority
                );

                item.setEnabled(false);
                menu.add(item);
            }

            if (!found) {
                javax.swing.JMenuItem empty = new javax.swing.JMenuItem(
                    "No upcoming unfinished tasks"
                );
                empty.setEnabled(false);
                menu.add(empty);
            }
        }

    } catch (java.sql.SQLException e) {
        javax.swing.JOptionPane.showMessageDialog(
            this,
            "Unable to load notifications:\n" + e.getMessage(),
            "Database Error",
            javax.swing.JOptionPane.ERROR_MESSAGE
        );
        return;
    }

    menu.show(lblNotification, 0, lblNotification.getHeight());
}


private void updateProfileIcon() {
    if (loggedInUser == null) {
        return;
    }

    String photoPath = loggedInUser.getProfilePhoto();

    // Show the default icon when no photo has been saved.
    if (photoPath == null || photoPath.trim().isEmpty()) {
        lblProfile.setIcon(
            new ImageIcon(
                getClass().getResource(
                    "/icons/account_circle_35dp_000000_FILL0_wght400_GRAD0_opsz40.png"
                )
            )
        );
        lblProfile.setText("");
        return;
    }

    try {
        java.io.File photoFile = new java.io.File(photoPath);

        if (!photoFile.exists()) {
            return;
        }

        java.awt.image.BufferedImage original =
            javax.imageio.ImageIO.read(photoFile);

        if (original == null) {
            return;
        }

        int size = Math.min(
            lblProfile.getWidth(),
            lblProfile.getHeight()
        );

        if (size <= 0) {
            size = 45;
        }

        java.awt.image.BufferedImage circle =
            new java.awt.image.BufferedImage(
                size,
                size,
                java.awt.image.BufferedImage.TYPE_INT_ARGB
            );

        Graphics2D g2 = circle.createGraphics();

        try {
            g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON
            );

            g2.setRenderingHint(
                RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BILINEAR
            );

            // Crop the photo into a circle.
            g2.setClip(
                new java.awt.geom.Ellipse2D.Float(
                    0, 0, size, size
                )
            );

            double scale = Math.max(
                (double) size / original.getWidth(),
                (double) size / original.getHeight()
            );

            int width = (int) Math.ceil(
                original.getWidth() * scale
            );

            int height = (int) Math.ceil(
                original.getHeight() * scale
            );

            Image scaled = original.getScaledInstance(
                width,
                height,
                Image.SCALE_SMOOTH
            );

            int x = (size - width) / 2;
            int y = (size - height) / 2;

            g2.drawImage(scaled, x, y, null);
        } finally {
            g2.dispose();
        }

        lblProfile.setText("");
        lblProfile.setIcon(new ImageIcon(circle));
        lblProfile.setHorizontalAlignment(
            SwingConstants.CENTER
        );
        lblProfile.setVerticalAlignment(
            SwingConstants.CENTER
        );

    } catch (java.io.IOException ex) {
        System.err.println(
            "Unable to load profile photo: " + ex.getMessage()
        );
    }
}





private void applyDashboardLayout() {

    contentPanel.removeAll();
    contentPanel.setLayout(new BorderLayout());

    JPanel leftDashboard = new JPanel(new GridBagLayout());
    leftDashboard.setOpaque(false);
    leftDashboard.setMinimumSize(new Dimension(0, 0));

    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(6, 6, 6, 6);
    gbc.fill = GridBagConstraints.BOTH;
    gbc.weightx = 1.0;

    // Welcome banner
    gbc.gridx = 0;
    gbc.gridy = 0;
    gbc.gridwidth = 3;
    gbc.weighty = 0.0;
    leftDashboard.add(panelWelcome, gbc);

    // Summary cards
    gbc.gridwidth = 1;
    gbc.gridy = 1;

    if (isStudent()) {

        cardUsers.setVisible(false);

        gbc.gridx = 0;
        leftDashboard.add(cardProjects, gbc);

        gbc.gridx = 1;
        leftDashboard.add(cardTasks, gbc);

        gbc.gridx = 2;
        leftDashboard.add(cardPendingtasks, gbc);

    } else {

        cardUsers.setVisible(true);

        gbc.gridx = 0;
        leftDashboard.add(cardUsers, gbc);

        gbc.gridx = 1;
        leftDashboard.add(cardProjects, gbc);

        gbc.gridy = 2;
        gbc.gridx = 0;
        leftDashboard.add(cardTasks, gbc);

        gbc.gridx = 1;
        leftDashboard.add(cardPendingtasks, gbc);
    }

    // Recent content panels
    JPanel lowerPanel = new JPanel(new GridLayout(1, 2, 12, 0));
    lowerPanel.setOpaque(false);
    lowerPanel.add(panelProjectOverview);
    lowerPanel.add(panelRecentTasks);

    gbc.gridx = 0;
    gbc.gridy = isStudent() ? 2 : 3;
    gbc.gridwidth = 3;
    gbc.weighty = 1.0;
    gbc.fill = GridBagConstraints.BOTH;
    leftDashboard.add(lowerPanel, gbc);

    // Upcoming Deadlines
     JPanel deadlineWrapper = new JPanel(new BorderLayout());
    deadlineWrapper.setOpaque(false);
    deadlineWrapper.setPreferredSize(new Dimension(260, 620));
    deadlineWrapper.setMinimumSize(new Dimension(300, 300));
    deadlineWrapper.setMaximumSize(new Dimension(300, Integer.MAX_VALUE));

    panelUpcomingDeadlines.setPreferredSize(new Dimension(260, 620));
    panelUpcomingDeadlines.setMinimumSize(new Dimension(300, 300));

    deadlineWrapper.add(panelUpcomingDeadlines, BorderLayout.CENTER);

    // Combine the left dashboard and deadlines
    JPanel dashboardArea = new JPanel(new GridBagLayout());
    dashboardArea.setOpaque(false);

    GridBagConstraints area = new GridBagConstraints();
    area.gridy = 0;
    area.fill = GridBagConstraints.BOTH;
    area.weighty = 1.0;

    // Left dashboard takes the remaining available width
    area.gridx = 0;
    area.weightx = 1.0;
    area.fill = GridBagConstraints.BOTH;
    area.insets = new Insets(0, 0, 0, 8);
    dashboardArea.add(leftDashboard, area);

    // Upcoming Deadlines stays at a fixed preferred width
    area.gridx = 1;
    area.weightx = 0.0;
    area.fill = GridBagConstraints.BOTH;
    area.insets = new Insets(0, 0, 0, 0);
    dashboardArea.add(deadlineWrapper, area);

    contentPanel.add(dashboardArea, BorderLayout.CENTER);

    contentPanel.revalidate();
    contentPanel.repaint();
}






private void showDashboard() {
    applyDashboardLayout();
}

private boolean isStudent() {
    return loggedInUser != null
            && "Student".equalsIgnoreCase(
                    loggedInUser.getRole() == null
                    ? ""
                    : loggedInUser.getRole().trim()
            );
}

private void configureRoleBasedAccess() {

    if (loggedInUser == null) {
        return;
    }

    boolean student = isStudent();

    // Admin can access these buttons; Student cannot
    btnTeam.setVisible(!student);
    btnReports.setVisible(!student);
    btnDatabase.setVisible(!student);

    // Configure the dashboard for each role
    if (student) {

        lblWelcomeTitle.setText(
            "Welcome, " + loggedInUser.getFirstName() + "!"
        );

        lblWelcomeSubtitle.setText(
            "Manage your projects and tasks in TASKFLOW."
        );

        lblTotalProjects1.setText("MY PROJECTS");
        lblCompletedtasks.setText("COMPLETED TASKS");

        cardUsers.setVisible(false);

    } else {

        lblWelcomeTitle.setText("Welcome back, Admin!");

        lblWelcomeSubtitle.setText(
            "Manage users, projects, and tasks to keep TASKFLOW running smoothly."
        );

        lblTotalProjects1.setText("TOTAL PROJECTS");
        lblCompletedtasks.setText("COMPLETED TASKS");

        cardUsers.setVisible(true);
    }

    // Display the logged-in user's information
    lblAdmin.setText(loggedInUser.getFullName());
    lblRole.setText(loggedInUser.getRole());
}


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        sidebarPanel = new javax.swing.JPanel();
        lblLogo = new javax.swing.JLabel();
        btnDashboard = new javax.swing.JButton();
        btnProjects = new javax.swing.JButton();
        btnTasks = new javax.swing.JButton();
        btnTeam = new javax.swing.JButton();
        btnReports = new javax.swing.JButton();
        btnDatabase = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        contentPanel = new javax.swing.JPanel();
        cardTasks = new javax.swing.JPanel();
        lblCompletedtasks = new javax.swing.JLabel();
        lblTasksCount = new javax.swing.JLabel();
        cardProjects = new javax.swing.JPanel();
        lblTotalProjects1 = new javax.swing.JLabel();
        lblProjectsCount1 = new javax.swing.JLabel();
        cardPendingtasks = new javax.swing.JPanel();
        lblPendingtasks = new javax.swing.JLabel();
        lblCompletedCount = new javax.swing.JLabel();
        panelProjectOverview = new javax.swing.JPanel();
        lblProject1Status = new javax.swing.JLabel();
        lblProject1Members = new javax.swing.JLabel();
        lblProjectOverview = new javax.swing.JLabel();
        lblProject1Members1 = new javax.swing.JLabel();
        lblProject1Members2 = new javax.swing.JLabel();
        lblViewAll = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jLabel6 = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();
        lblProgressValue = new javax.swing.JLabel();
        lblTeamIcon = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jSeparator7 = new javax.swing.JSeparator();
        panelRecentTasks = new javax.swing.JPanel();
        lblRecentTasksTitle = new javax.swing.JLabel();
        lblTaskName = new javax.swing.JLabel();
        lblProject = new javax.swing.JLabel();
        lblPriority1 = new javax.swing.JLabel();
        lblDeadline = new javax.swing.JLabel();
        lblStatus = new javax.swing.JLabel();
        jSeparator8 = new javax.swing.JSeparator();
        lblViewAll1 = new javax.swing.JLabel();
        jSeparator10 = new javax.swing.JSeparator();
        lbltaskname1 = new javax.swing.JLabel();
        lbltaskname2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jSeparator11 = new javax.swing.JSeparator();
        panelWelcome = new javax.swing.JPanel();
        lblWelcomeTitle = new javax.swing.JLabel();
        lblWelcomeSubtitle = new javax.swing.JLabel();
        lblWelcomeQuote = new javax.swing.JLabel();
        cardUsers = new javax.swing.JPanel();
        lblTotalUsers = new javax.swing.JLabel();
        lblUsersCount = new javax.swing.JLabel();
        panelUpcomingDeadlines = new javax.swing.JPanel();
        lblUpcomingDeadlines = new javax.swing.JLabel();
        lblDeadlineSubtitle = new javax.swing.JLabel();
        sepUpcomingDeadlines = new javax.swing.JSeparator();
        scrollUpcomingDeadlines = new javax.swing.JScrollPane();
        DeadlinesListPanel1 = new javax.swing.JPanel();
        panelTopBar = new javax.swing.JPanel();
        panelSearch = new javax.swing.JPanel();
        txtSearch = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        lblNotification = new javax.swing.JLabel();
        lblProfile = new javax.swing.JLabel();
        lblAdmin = new javax.swing.JLabel();
        lblRole = new javax.swing.JLabel();

        sidebarPanel.setBackground(new java.awt.Color(11, 45, 92));

        lblLogo.setBackground(new java.awt.Color(255, 255, 255));
        lblLogo.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        lblLogo.setForeground(new java.awt.Color(255, 255, 255));
        lblLogo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblLogo.setText("TASKFLOW");

        btnDashboard.setBackground(new java.awt.Color(11, 45, 92));
        btnDashboard.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        btnDashboard.setForeground(new java.awt.Color(255, 255, 255));
        btnDashboard.setText("Dashboard");
        btnDashboard.setBorderPainted(false);
        btnDashboard.setFocusPainted(false);
        btnDashboard.setOpaque(true);
        btnDashboard.addActionListener(this::btnDashboardActionPerformed);

        btnProjects.setBackground(new java.awt.Color(11, 45, 92));
        btnProjects.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        btnProjects.setForeground(new java.awt.Color(255, 255, 255));
        btnProjects.setText("Projects");
        btnProjects.setBorderPainted(false);
        btnProjects.setOpaque(true);
        btnProjects.addActionListener(this::btnProjectsActionPerformed);

        btnTasks.setBackground(new java.awt.Color(11, 45, 92));
        btnTasks.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        btnTasks.setForeground(new java.awt.Color(255, 255, 255));
        btnTasks.setText("Tasks");
        btnTasks.setBorderPainted(false);
        btnTasks.setOpaque(true);
        btnTasks.addActionListener(this::btnTasksActionPerformed);

        btnTeam.setBackground(new java.awt.Color(11, 45, 92));
        btnTeam.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        btnTeam.setForeground(new java.awt.Color(255, 255, 255));
        btnTeam.setText("Team Management");
        btnTeam.setBorderPainted(false);
        btnTeam.setOpaque(true);
        btnTeam.addActionListener(this::btnTeamActionPerformed);

        btnReports.setBackground(new java.awt.Color(11, 45, 92));
        btnReports.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        btnReports.setForeground(new java.awt.Color(255, 255, 255));
        btnReports.setText("Reports & Analytics");
        btnReports.setBorderPainted(false);
        btnReports.setOpaque(true);
        btnReports.addActionListener(this::btnReportsActionPerformed);

        btnDatabase.setBackground(new java.awt.Color(11, 45, 92));
        btnDatabase.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        btnDatabase.setForeground(new java.awt.Color(255, 255, 255));
        btnDatabase.setText("Database Management");
        btnDatabase.setBorderPainted(false);
        btnDatabase.setOpaque(true);
        btnDatabase.addActionListener(this::btnDatabaseActionPerformed);

        jSeparator1.setForeground(new java.awt.Color(54, 87, 125));
        jSeparator1.setPreferredSize(new java.awt.Dimension(210, 1));

        jSeparator2.setForeground(new java.awt.Color(66, 106, 150));
        jSeparator2.setPreferredSize(new java.awt.Dimension(210, 10));

        javax.swing.GroupLayout sidebarPanelLayout = new javax.swing.GroupLayout(sidebarPanel);
        sidebarPanel.setLayout(sidebarPanelLayout);
        sidebarPanelLayout.setHorizontalGroup(
            sidebarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sidebarPanelLayout.createSequentialGroup()
                .addGroup(sidebarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(sidebarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(sidebarPanelLayout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, sidebarPanelLayout.createSequentialGroup()
                            .addGap(29, 29, 29)
                            .addGroup(sidebarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(sidebarPanelLayout.createSequentialGroup()
                                    .addGroup(sidebarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(btnDatabase)
                                        .addComponent(btnReports)
                                        .addComponent(btnTeam)
                                        .addComponent(btnProjects)
                                        .addComponent(btnDashboard)
                                        .addComponent(btnTasks))
                                    .addGap(20, 20, 20)))))
                    .addGroup(sidebarPanelLayout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(lblLogo, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(29, Short.MAX_VALUE))
        );
        sidebarPanelLayout.setVerticalGroup(
            sidebarPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(sidebarPanelLayout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(lblLogo)
                .addGap(39, 39, 39)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 18, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnDashboard)
                .addGap(18, 18, 18)
                .addComponent(btnProjects)
                .addGap(18, 18, 18)
                .addComponent(btnTasks)
                .addGap(18, 18, 18)
                .addComponent(btnTeam)
                .addGap(18, 18, 18)
                .addComponent(btnReports)
                .addGap(18, 18, 18)
                .addComponent(btnDatabase)
                .addGap(50, 50, 50)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        contentPanel.setBackground(new java.awt.Color(245, 248, 252));
        contentPanel.setPreferredSize(new java.awt.Dimension(1000, 780));

        cardTasks.setBackground(new java.awt.Color(255, 255, 255));
        cardTasks.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 228, 240), 1, true));
        cardTasks.setForeground(new java.awt.Color(11, 45, 92));
        cardTasks.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        cardTasks.setPreferredSize(new java.awt.Dimension(210, 125));

        lblCompletedtasks.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblCompletedtasks.setForeground(new java.awt.Color(18, 58, 115));
        lblCompletedtasks.setText("COMPLETED TASKS");

        lblTasksCount.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        lblTasksCount.setForeground(new java.awt.Color(11, 45, 92));
        lblTasksCount.setText("0");

        javax.swing.GroupLayout cardTasksLayout = new javax.swing.GroupLayout(cardTasks);
        cardTasks.setLayout(cardTasksLayout);
        cardTasksLayout.setHorizontalGroup(
            cardTasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardTasksLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardTasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTasksCount, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblCompletedtasks))
                .addContainerGap(294, Short.MAX_VALUE))
        );
        cardTasksLayout.setVerticalGroup(
            cardTasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardTasksLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblCompletedtasks)
                .addGap(21, 21, 21)
                .addComponent(lblTasksCount)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        cardProjects.setBackground(new java.awt.Color(255, 255, 255));
        cardProjects.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 228, 240), 1, true));
        cardProjects.setForeground(new java.awt.Color(11, 45, 92));
        cardProjects.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        cardProjects.setPreferredSize(new java.awt.Dimension(210, 125));

        lblTotalProjects1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTotalProjects1.setForeground(new java.awt.Color(18, 58, 115));
        lblTotalProjects1.setText("TOTAL PROJECTS");

        lblProjectsCount1.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        lblProjectsCount1.setForeground(new java.awt.Color(11, 45, 92));
        lblProjectsCount1.setText("0");

        javax.swing.GroupLayout cardProjectsLayout = new javax.swing.GroupLayout(cardProjects);
        cardProjects.setLayout(cardProjectsLayout);
        cardProjectsLayout.setHorizontalGroup(
            cardProjectsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardProjectsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardProjectsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblProjectsCount1, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTotalProjects1))
                .addContainerGap(303, Short.MAX_VALUE))
        );
        cardProjectsLayout.setVerticalGroup(
            cardProjectsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardProjectsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTotalProjects1)
                .addGap(21, 21, 21)
                .addComponent(lblProjectsCount1)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        cardPendingtasks.setBackground(new java.awt.Color(255, 255, 255));
        cardPendingtasks.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 228, 240), 1, true));
        cardPendingtasks.setForeground(new java.awt.Color(11, 45, 92));
        cardPendingtasks.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        cardPendingtasks.setPreferredSize(new java.awt.Dimension(210, 125));

        lblPendingtasks.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblPendingtasks.setForeground(new java.awt.Color(18, 58, 115));
        lblPendingtasks.setText("PENDING TASKS");

        lblCompletedCount.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        lblCompletedCount.setForeground(new java.awt.Color(11, 45, 92));
        lblCompletedCount.setText("0");

        javax.swing.GroupLayout cardPendingtasksLayout = new javax.swing.GroupLayout(cardPendingtasks);
        cardPendingtasks.setLayout(cardPendingtasksLayout);
        cardPendingtasksLayout.setHorizontalGroup(
            cardPendingtasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardPendingtasksLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardPendingtasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblCompletedCount, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPendingtasks))
                .addContainerGap(309, Short.MAX_VALUE))
        );
        cardPendingtasksLayout.setVerticalGroup(
            cardPendingtasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardPendingtasksLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblPendingtasks)
                .addGap(21, 21, 21)
                .addComponent(lblCompletedCount)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelProjectOverview.setBackground(new java.awt.Color(255, 255, 255));
        panelProjectOverview.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 228, 240), 1, true));
        panelProjectOverview.setPreferredSize(new java.awt.Dimension(354, 450));

        lblProject1Status.setBackground(new java.awt.Color(35, 116, 209));
        lblProject1Status.setForeground(new java.awt.Color(71, 85, 105));
        lblProject1Status.setText("Project Name");

        lblProject1Members.setBackground(new java.awt.Color(100, 116, 139));
        lblProject1Members.setForeground(new java.awt.Color(71, 85, 105));
        lblProject1Members.setText("Progress");

        lblProjectOverview.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblProjectOverview.setForeground(new java.awt.Color(18, 58, 115));
        lblProjectOverview.setText("Project Overview");

        lblProject1Members1.setBackground(new java.awt.Color(100, 116, 139));
        lblProject1Members1.setForeground(new java.awt.Color(71, 85, 105));
        lblProject1Members1.setText("Team");

        lblProject1Members2.setBackground(new java.awt.Color(100, 116, 139));
        lblProject1Members2.setForeground(new java.awt.Color(71, 85, 105));
        lblProject1Members2.setText("Status");

        lblViewAll.setText("View All");

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(23, 59, 108));
        jLabel6.setText("TASKFLOW");

        jProgressBar1.setForeground(new java.awt.Color(40, 101, 181));
        jProgressBar1.setValue(50);
        jProgressBar1.setPreferredSize(new java.awt.Dimension(10, 4));

        lblProgressValue.setBackground(new java.awt.Color(23, 59, 108));
        lblProgressValue.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        lblProgressValue.setForeground(new java.awt.Color(23, 59, 108));
        lblProgressValue.setText("50%");

        lblTeamIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/group_18dp_173B6C_FILL0_wght400_GRAD0_opszTWO.png"))); // NOI18N

        jLabel5.setFont(new java.awt.Font("Segoe UI Semibold", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(23, 59, 108));
        jLabel5.setText("3");

        jLabel7.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(39, 101, 181));
        jLabel7.setText("In Progress");

        javax.swing.GroupLayout panelProjectOverviewLayout = new javax.swing.GroupLayout(panelProjectOverview);
        panelProjectOverview.setLayout(panelProjectOverviewLayout);
        panelProjectOverviewLayout.setHorizontalGroup(
            panelProjectOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelProjectOverviewLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelProjectOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelProjectOverviewLayout.createSequentialGroup()
                        .addGroup(panelProjectOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator7)
                            .addGroup(panelProjectOverviewLayout.createSequentialGroup()
                                .addComponent(lblProjectOverview)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblViewAll)
                                .addGap(23, 23, 23))
                            .addComponent(jSeparator6, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addContainerGap())
                    .addGroup(panelProjectOverviewLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(panelProjectOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelProjectOverviewLayout.createSequentialGroup()
                                .addComponent(lblProject1Status)
                                .addGap(64, 64, 64)
                                .addComponent(lblProject1Members)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblProject1Members1)
                                .addGap(47, 47, 47)
                                .addComponent(lblProject1Members2)
                                .addGap(69, 69, 69))
                            .addGroup(panelProjectOverviewLayout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblProgressValue, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(lblTeamIcon)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                                .addComponent(jLabel7)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))))))
        );
        panelProjectOverviewLayout.setVerticalGroup(
            panelProjectOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelProjectOverviewLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelProjectOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblProjectOverview)
                    .addComponent(lblViewAll))
                .addGap(7, 7, 7)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addGroup(panelProjectOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblProject1Members)
                    .addGroup(panelProjectOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblProject1Status)
                        .addComponent(lblProject1Members2)
                        .addComponent(lblProject1Members1)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator6, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(panelProjectOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelProjectOverviewLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelProjectOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelProjectOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel6)
                                .addComponent(lblProgressValue))
                            .addGroup(panelProjectOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(panelProjectOverviewLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel7))
                                .addComponent(lblTeamIcon))))
                    .addGroup(panelProjectOverviewLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jLabel4))
                    .addGroup(panelProjectOverviewLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jProgressBar1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator7, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(175, Short.MAX_VALUE))
        );

        panelRecentTasks.setBackground(new java.awt.Color(255, 255, 255));
        panelRecentTasks.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 228, 240), 1, true));

        lblRecentTasksTitle.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblRecentTasksTitle.setForeground(new java.awt.Color(18, 58, 115));
        lblRecentTasksTitle.setText("Recent Tasks");

        lblTaskName.setBackground(new java.awt.Color(35, 116, 209));
        lblTaskName.setForeground(new java.awt.Color(71, 85, 105));
        lblTaskName.setText("Task Name");

        lblProject.setBackground(new java.awt.Color(35, 116, 209));
        lblProject.setForeground(new java.awt.Color(71, 85, 105));
        lblProject.setText("Project");

        lblPriority1.setBackground(new java.awt.Color(35, 116, 209));
        lblPriority1.setForeground(new java.awt.Color(71, 85, 105));
        lblPriority1.setText("Priority");

        lblDeadline.setBackground(new java.awt.Color(35, 116, 209));
        lblDeadline.setForeground(new java.awt.Color(71, 85, 105));
        lblDeadline.setText("Deadline");

        lblStatus.setBackground(new java.awt.Color(35, 116, 209));
        lblStatus.setForeground(new java.awt.Color(71, 85, 105));
        lblStatus.setText("Status");

        lblViewAll1.setText("View All");

        lbltaskname1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lbltaskname1.setForeground(new java.awt.Color(23, 59, 108));
        lbltaskname1.setText("Design Homepage");

        lbltaskname2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lbltaskname2.setForeground(new java.awt.Color(23, 59, 108));
        lbltaskname2.setText("TASKFLOW");

        jLabel8.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(39, 101, 181));
        jLabel8.setText("High");

        jLabel9.setFont(new java.awt.Font("Segoe UI Semibold", 0, 10)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(23, 59, 108));
        jLabel9.setText("May 15, 2026");

        jLabel10.setFont(new java.awt.Font("Segoe UI Semibold", 0, 12)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(39, 101, 181));
        jLabel10.setText("In Progress");

        javax.swing.GroupLayout panelRecentTasksLayout = new javax.swing.GroupLayout(panelRecentTasks);
        panelRecentTasks.setLayout(panelRecentTasksLayout);
        panelRecentTasksLayout.setHorizontalGroup(
            panelRecentTasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRecentTasksLayout.createSequentialGroup()
                .addGroup(panelRecentTasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelRecentTasksLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(lblTaskName)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(lblProject)
                        .addGap(40, 40, 40)
                        .addComponent(lblPriority1)
                        .addGap(26, 26, 26)
                        .addComponent(lblDeadline)
                        .addGap(44, 44, 44)
                        .addComponent(lblStatus)
                        .addGap(19, 19, 19))
                    .addGroup(panelRecentTasksLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(panelRecentTasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator8, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jSeparator10)
                            .addGroup(panelRecentTasksLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(lbltaskname1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lbltaskname2)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel8)
                                .addGap(26, 26, 26)
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel10)
                                .addGap(0, 6, Short.MAX_VALUE))
                            .addGroup(panelRecentTasksLayout.createSequentialGroup()
                                .addComponent(lblRecentTasksTitle)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblViewAll1)
                                .addGap(25, 25, 25))))
                    .addGroup(panelRecentTasksLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jSeparator11)))
                .addContainerGap())
        );
        panelRecentTasksLayout.setVerticalGroup(
            panelRecentTasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelRecentTasksLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelRecentTasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblRecentTasksTitle)
                    .addComponent(lblViewAll1))
                .addGap(7, 7, 7)
                .addComponent(jSeparator8, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addGroup(panelRecentTasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblProject)
                    .addComponent(lblPriority1)
                    .addGroup(panelRecentTasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblTaskName)
                        .addComponent(lblStatus)
                        .addComponent(lblDeadline)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator10, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelRecentTasksLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lbltaskname1)
                    .addComponent(lbltaskname2)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator11, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelWelcome.setBackground(new java.awt.Color(225, 239, 255));
        panelWelcome.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 228, 240), 1, true));

        lblWelcomeTitle.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        lblWelcomeTitle.setForeground(new java.awt.Color(11, 45, 92));
        lblWelcomeTitle.setText("Welcome back, Admin!");

        lblWelcomeSubtitle.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        lblWelcomeSubtitle.setForeground(new java.awt.Color(21, 84, 164));
        lblWelcomeSubtitle.setText("Manage users, projects, and tasks to keep TASKFLOW running smoothly.");

        lblWelcomeQuote.setFont(new java.awt.Font("Segoe UI", 2, 12)); // NOI18N
        lblWelcomeQuote.setForeground(new java.awt.Color(21, 84, 164));
        lblWelcomeQuote.setText("“Good management builds great teams.”");

        javax.swing.GroupLayout panelWelcomeLayout = new javax.swing.GroupLayout(panelWelcome);
        panelWelcome.setLayout(panelWelcomeLayout);
        panelWelcomeLayout.setHorizontalGroup(
            panelWelcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelWelcomeLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(panelWelcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblWelcomeTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 332, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblWelcomeQuote)
                    .addComponent(lblWelcomeSubtitle))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelWelcomeLayout.setVerticalGroup(
            panelWelcomeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelWelcomeLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(lblWelcomeTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblWelcomeSubtitle)
                .addGap(18, 18, 18)
                .addComponent(lblWelcomeQuote)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        cardUsers.setBackground(new java.awt.Color(255, 255, 255));
        cardUsers.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(214, 228, 240), 1, true));
        cardUsers.setForeground(new java.awt.Color(11, 45, 92));
        cardUsers.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        cardUsers.setPreferredSize(new java.awt.Dimension(210, 125));

        lblTotalUsers.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblTotalUsers.setForeground(new java.awt.Color(18, 58, 115));
        lblTotalUsers.setText("TOTAL USERS");

        lblUsersCount.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        lblUsersCount.setForeground(new java.awt.Color(11, 45, 92));
        lblUsersCount.setText("0");

        javax.swing.GroupLayout cardUsersLayout = new javax.swing.GroupLayout(cardUsers);
        cardUsers.setLayout(cardUsersLayout);
        cardUsersLayout.setHorizontalGroup(
            cardUsersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardUsersLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(cardUsersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblUsersCount, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTotalUsers))
                .addContainerGap(334, Short.MAX_VALUE))
        );
        cardUsersLayout.setVerticalGroup(
            cardUsersLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cardUsersLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTotalUsers)
                .addGap(21, 21, 21)
                .addComponent(lblUsersCount)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelUpcomingDeadlines.setBackground(new java.awt.Color(255, 255, 255));

        lblUpcomingDeadlines.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblUpcomingDeadlines.setForeground(new java.awt.Color(18, 58, 115));
        lblUpcomingDeadlines.setText("Upcoming Deadlines");

        lblDeadlineSubtitle.setBackground(new java.awt.Color(35, 116, 209));
        lblDeadlineSubtitle.setFont(new java.awt.Font("Segoe UI Semibold", 1, 12)); // NOI18N
        lblDeadlineSubtitle.setForeground(new java.awt.Color(71, 85, 105));
        lblDeadlineSubtitle.setText("Tasks that need your attention");

        scrollUpcomingDeadlines.setHorizontalScrollBar(null);

        DeadlinesListPanel1.setBackground(new java.awt.Color(255, 255, 255));
        DeadlinesListPanel1.setLayout(new javax.swing.BoxLayout(DeadlinesListPanel1, javax.swing.BoxLayout.LINE_AXIS));
        scrollUpcomingDeadlines.setViewportView(DeadlinesListPanel1);

        javax.swing.GroupLayout panelUpcomingDeadlinesLayout = new javax.swing.GroupLayout(panelUpcomingDeadlines);
        panelUpcomingDeadlines.setLayout(panelUpcomingDeadlinesLayout);
        panelUpcomingDeadlinesLayout.setHorizontalGroup(
            panelUpcomingDeadlinesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelUpcomingDeadlinesLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(panelUpcomingDeadlinesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblUpcomingDeadlines)
                    .addComponent(lblDeadlineSubtitle)
                    .addComponent(scrollUpcomingDeadlines, javax.swing.GroupLayout.DEFAULT_SIZE, 344, Short.MAX_VALUE)
                    .addComponent(sepUpcomingDeadlines))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        panelUpcomingDeadlinesLayout.setVerticalGroup(
            panelUpcomingDeadlinesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelUpcomingDeadlinesLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblUpcomingDeadlines)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblDeadlineSubtitle)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sepUpcomingDeadlines, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollUpcomingDeadlines, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout contentPanelLayout = new javax.swing.GroupLayout(contentPanel);
        contentPanel.setLayout(contentPanelLayout);
        contentPanelLayout.setHorizontalGroup(
            contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contentPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(contentPanelLayout.createSequentialGroup()
                        .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(panelProjectOverview, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cardUsers, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cardTasks, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(contentPanelLayout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cardPendingtasks, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 431, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cardProjects, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 431, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(contentPanelLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(panelRecentTasks, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(panelWelcome, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(panelUpcomingDeadlines, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(427, 427, 427))
        );
        contentPanelLayout.setVerticalGroup(
            contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(contentPanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(panelUpcomingDeadlines, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(contentPanelLayout.createSequentialGroup()
                        .addComponent(panelWelcome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cardUsers, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
                            .addComponent(cardProjects, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cardPendingtasks, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE)
                            .addComponent(cardTasks, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(contentPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(panelRecentTasks, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(panelProjectOverview, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(92, Short.MAX_VALUE))
        );

        panelTopBar.setBackground(new java.awt.Color(255, 255, 255));
        panelTopBar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(214, 228, 240)));

        panelSearch.setBackground(new java.awt.Color(232, 243, 255));
        panelSearch.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(195, 223, 255), 1, true));
        panelSearch.setPreferredSize(new java.awt.Dimension(545, 40));

        txtSearch.setBackground(new java.awt.Color(232, 243, 255));
        txtSearch.setForeground(new java.awt.Color(39, 101, 181));
        txtSearch.setText("Search projects, tasks, or members...");
        txtSearch.setBorder(null);
        txtSearch.setPreferredSize(new java.awt.Dimension(545, 40));
        txtSearch.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                txtSearchFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtSearchFocusLost(evt);
            }
        });
        txtSearch.addActionListener(this::txtSearchActionPerformed);

        jLabel1.setBackground(new java.awt.Color(0, 0, 0));
        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/searchnew.png"))); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout panelSearchLayout = new javax.swing.GroupLayout(panelSearch);
        panelSearch.setLayout(panelSearchLayout);
        panelSearchLayout.setHorizontalGroup(
            panelSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelSearchLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtSearch, javax.swing.GroupLayout.DEFAULT_SIZE, 483, Short.MAX_VALUE)
                .addContainerGap())
        );
        panelSearchLayout.setVerticalGroup(
            panelSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelSearchLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(txtSearch, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        lblNotification.setForeground(new java.awt.Color(23, 59, 108));
        lblNotification.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/notifications_35dp_000000_FILL0_wght400_GRAD0_opsz40.png"))); // NOI18N
        lblNotification.setText("jLabel2");
        lblNotification.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblNotificationMouseClicked(evt);
            }
        });

        lblProfile.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/account_circle_35dp_000000_FILL0_wght400_GRAD0_opsz40.png"))); // NOI18N
        lblProfile.setText("jLabel2");
        lblProfile.setPreferredSize(new java.awt.Dimension(45, 45));
        lblProfile.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblProfileMouseClicked(evt);
            }
        });

        lblAdmin.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lblAdmin.setForeground(new java.awt.Color(23, 59, 108));
        lblAdmin.setText("Admin");

        lblRole.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        lblRole.setForeground(new java.awt.Color(100, 116, 139));
        lblRole.setText("Administrator");

        javax.swing.GroupLayout panelTopBarLayout = new javax.swing.GroupLayout(panelTopBar);
        panelTopBar.setLayout(panelTopBarLayout);
        panelTopBarLayout.setHorizontalGroup(
            panelTopBarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTopBarLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(panelSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 530, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 552, Short.MAX_VALUE)
                .addComponent(lblNotification, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblProfile, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelTopBarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblRole)
                    .addComponent(lblAdmin))
                .addGap(48, 48, 48))
        );
        panelTopBarLayout.setVerticalGroup(
            panelTopBarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTopBarLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelTopBarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelTopBarLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(lblRole)
                        .addContainerGap())
                    .addGroup(panelTopBarLayout.createSequentialGroup()
                        .addGroup(panelTopBarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelTopBarLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(lblProfile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblNotification)
                                .addComponent(lblAdmin))
                            .addComponent(panelSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 1, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(sidebarPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(contentPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 1290, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(panelTopBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(sidebarPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(panelTopBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(contentPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 811, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnTeamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTeamActionPerformed
 
     if (loggedInUser == null) {
        JOptionPane.showMessageDialog(
            this,
            "User information is missing. Please log in again."
        );
        return;
    }

    if (isStudent()) {
        JOptionPane.showMessageDialog(
            this,
            "Access denied. This feature is for administrators only.",
            "Access Denied",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    setActiveButton(btnTeam);
    contentPanel.removeAll();
    contentPanel.setLayout(new java.awt.BorderLayout());

    contentPanel.add(new MemberPanel(), java.awt.BorderLayout.CENTER);

    contentPanel.revalidate();
    contentPanel.repaint();


    // Keep your existing code for opening the Reports screen here.

    // TODO add your handling code here:
    }//GEN-LAST:event_btnTeamActionPerformed

    private void btnDatabaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDatabaseActionPerformed

    if (loggedInUser == null) {
        JOptionPane.showMessageDialog(
            this,
            "User information is missing. Please log in again."
        );
        return;
    }

    if (isStudent()) {
        JOptionPane.showMessageDialog(
            this,
            "Access denied. This feature is for administrators only.",
            "Access Denied",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    setActiveButton(btnDatabase);
    contentPanel.removeAll();
    contentPanel.setLayout(new java.awt.BorderLayout());

    contentPanel.add(new DatabasePanel(), java.awt.BorderLayout.CENTER);

    contentPanel.revalidate();
    contentPanel.repaint();



    // Keep your existing code for opening the Reports screen here.

    }//GEN-LAST:event_btnDatabaseActionPerformed

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
      JOptionPane.showMessageDialog(this, "Search method is running!");
        
        searchAll();
    }//GEN-LAST:event_txtSearchActionPerformed

    private void txtSearchFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtSearchFocusGained

    txtSearch.setText("");
    
    }//GEN-LAST:event_txtSearchFocusGained

    private void txtSearchFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtSearchFocusLost
     if (txtSearch.getText().trim().isEmpty()) {
        txtSearch.setText("Search projects, tasks, or members...");
    }
    }//GEN-LAST:event_txtSearchFocusLost

    private void lblProfileMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblProfileMouseClicked
     showProfileMenu();
    }//GEN-LAST:event_lblProfileMouseClicked

    private void lblNotificationMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblNotificationMouseClicked
    showNotifications();    // TODO add your handling code here:
    }//GEN-LAST:event_lblNotificationMouseClicked

    private void btnProjectsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProjectsActionPerformed
     setActiveButton(btnProjects);

    contentPanel.removeAll();
    contentPanel.setLayout(new java.awt.BorderLayout());

    ProjectsPanel projectsPanel = new ProjectsPanel();
    contentPanel.add(projectsPanel, java.awt.BorderLayout.CENTER);

    contentPanel.revalidate();
    contentPanel.repaint();


    }//GEN-LAST:event_btnProjectsActionPerformed

    private void btnDashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDashboardActionPerformed
      setActiveButton(btnDashboard);
    showDashboard();
    }//GEN-LAST:event_btnDashboardActionPerformed

    private void btnTasksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTasksActionPerformed
    setActiveButton(btnTasks);

    contentPanel.removeAll();
    contentPanel.setLayout(new java.awt.BorderLayout());

    contentPanel.add(new TaskPanel(), java.awt.BorderLayout.CENTER);

    contentPanel.revalidate();
    contentPanel.repaint();
    // TODO add your handling code here:
    }//GEN-LAST:event_btnTasksActionPerformed

    private void btnReportsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReportsActionPerformed

    if (loggedInUser == null) {
        JOptionPane.showMessageDialog(
            this,
            "User information is missing. Please log in again."
        );
        return;
    }

    if (isStudent()) {
        JOptionPane.showMessageDialog(
            this,
            "Access denied. This feature is for administrators only.",
            "Access Denied",
            JOptionPane.WARNING_MESSAGE
        );
        return;
    }

    setActiveButton(btnReports);
    contentPanel.removeAll();
    contentPanel.setLayout(new java.awt.BorderLayout());

    contentPanel.add(new ReportsPanel(), java.awt.BorderLayout.CENTER);

    contentPanel.revalidate();
    contentPanel.repaint();


    // Keep your existing code for opening the Reports screen here.

    }//GEN-LAST:event_btnReportsActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel DeadlinesListPanel1;
    private javax.swing.JButton btnDashboard;
    private javax.swing.JButton btnDatabase;
    private javax.swing.JButton btnProjects;
    private javax.swing.JButton btnReports;
    private javax.swing.JButton btnTasks;
    private javax.swing.JButton btnTeam;
    private javax.swing.JPanel cardPendingtasks;
    private javax.swing.JPanel cardProjects;
    private javax.swing.JPanel cardTasks;
    private javax.swing.JPanel cardUsers;
    private javax.swing.JPanel contentPanel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator10;
    private javax.swing.JSeparator jSeparator11;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JLabel lblAdmin;
    private javax.swing.JLabel lblCompletedCount;
    private javax.swing.JLabel lblCompletedtasks;
    private javax.swing.JLabel lblDeadline;
    private javax.swing.JLabel lblDeadlineSubtitle;
    private javax.swing.JLabel lblLogo;
    private javax.swing.JLabel lblNotification;
    private javax.swing.JLabel lblPendingtasks;
    private javax.swing.JLabel lblPriority1;
    private javax.swing.JLabel lblProfile;
    private javax.swing.JLabel lblProgressValue;
    private javax.swing.JLabel lblProject;
    private javax.swing.JLabel lblProject1Members;
    private javax.swing.JLabel lblProject1Members1;
    private javax.swing.JLabel lblProject1Members2;
    private javax.swing.JLabel lblProject1Status;
    private javax.swing.JLabel lblProjectOverview;
    private javax.swing.JLabel lblProjectsCount1;
    private javax.swing.JLabel lblRecentTasksTitle;
    private javax.swing.JLabel lblRole;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblTaskName;
    private javax.swing.JLabel lblTasksCount;
    private javax.swing.JLabel lblTeamIcon;
    private javax.swing.JLabel lblTotalProjects1;
    private javax.swing.JLabel lblTotalUsers;
    private javax.swing.JLabel lblUpcomingDeadlines;
    private javax.swing.JLabel lblUsersCount;
    private javax.swing.JLabel lblViewAll;
    private javax.swing.JLabel lblViewAll1;
    private javax.swing.JLabel lblWelcomeQuote;
    private javax.swing.JLabel lblWelcomeSubtitle;
    private javax.swing.JLabel lblWelcomeTitle;
    private javax.swing.JLabel lbltaskname1;
    private javax.swing.JLabel lbltaskname2;
    private javax.swing.JPanel panelProjectOverview;
    private javax.swing.JPanel panelRecentTasks;
    private javax.swing.JPanel panelSearch;
    private javax.swing.JPanel panelTopBar;
    private javax.swing.JPanel panelUpcomingDeadlines;
    private javax.swing.JPanel panelWelcome;
    private javax.swing.JScrollPane scrollUpcomingDeadlines;
    private javax.swing.JSeparator sepUpcomingDeadlines;
    private javax.swing.JPanel sidebarPanel;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}

