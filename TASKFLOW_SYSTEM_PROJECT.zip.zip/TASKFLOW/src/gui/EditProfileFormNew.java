
package gui;

import dao.UserDAO;
import model.User;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.imageio.ImageIO;

public class EditProfileFormNew extends JFrame {

    private final User loggedInUser;
    private final UserDAO userDAO = new UserDAO();

    private JLabel lblPhoto;
    private JTextField txtFirstName;
    private JTextField txtLastName;
    private JTextField txtEmail;
    private JTextField txtPhone;

    private JButton btnUpload;
    private JButton btnSave;
    private JButton btnCancel;

    private String selectedPhotoPath;

    public EditProfileFormNew(User user) {
        if (user == null) {
            throw new IllegalArgumentException("User cannot be null.");
        }

        this.loggedInUser = user;
        this.selectedPhotoPath = user.getProfilePhoto();

        initForm();
        loadUserData();
        loadPhotoPreview();
    }

    private void initForm() {
        setTitle("TASKFLOW - Edit Profile");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(520, 650);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel main = new JPanel(new GridBagLayout());
        main.setBackground(Color.WHITE);
        main.setBorder(
                BorderFactory.createEmptyBorder(20, 35, 20, 35));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(7, 5, 7, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;

        JLabel title = new JLabel(
                "EDIT PROFILE", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 23));
        title.setForeground(new Color(23, 59, 108));
        main.add(title, gbc);

        gbc.gridy++;

        lblPhoto = new JLabel("No Photo", SwingConstants.CENTER);
        lblPhoto.setPreferredSize(new Dimension(130, 130));
        lblPhoto.setHorizontalAlignment(SwingConstants.CENTER);
        lblPhoto.setVerticalAlignment(SwingConstants.CENTER);
        lblPhoto.setOpaque(false);
        main.add(lblPhoto, gbc);

        gbc.gridy++;

        btnUpload = new JButton("Upload Photo");
        main.add(btnUpload, gbc);

        gbc.gridy++;
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        main.add(new JLabel("First Name"), gbc);

        gbc.gridx = 1;
        txtFirstName = new JTextField(15);
        main.add(txtFirstName, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        main.add(new JLabel("Last Name"), gbc);

        gbc.gridx = 1;
        txtLastName = new JTextField(15);
        main.add(txtLastName, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        main.add(new JLabel("Email"), gbc);

        gbc.gridx = 1;
        txtEmail = new JTextField(15);
        main.add(txtEmail, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        main.add(new JLabel("Phone Number"), gbc);

        gbc.gridx = 1;
        txtPhone = new JTextField(15);
        main.add(txtPhone, gbc);

        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;

        JPanel actions = new JPanel(
                new FlowLayout(FlowLayout.CENTER, 12, 5));
        actions.setOpaque(false);

        btnSave = new JButton("Save Changes");
        btnCancel = new JButton("Cancel");

        actions.add(btnSave);
        actions.add(btnCancel);
        main.add(actions, gbc);

        add(main);

        btnUpload.addActionListener(e -> choosePhoto());
        btnSave.addActionListener(e -> saveProfile());
        btnCancel.addActionListener(e -> dispose());
    }

    
private void loadUserData() {
    // Get the latest user details from MySQL
    model.User latestUser =
            userDAO.getUserByUsername(loggedInUser.getUsername());

    if (latestUser != null) {
        loggedInUser.setFirstName(latestUser.getFirstName());
        loggedInUser.setLastName(latestUser.getLastName());
        loggedInUser.setEmail(latestUser.getEmail());
        loggedInUser.setPhoneNumber(latestUser.getPhoneNumber());
        loggedInUser.setProfilePhoto(latestUser.getProfilePhoto());
    }

    txtFirstName.setText(
            loggedInUser.getFirstName() == null
                    ? "" : loggedInUser.getFirstName());

    txtLastName.setText(
            loggedInUser.getLastName() == null
                    ? "" : loggedInUser.getLastName());

    txtEmail.setText(
            loggedInUser.getEmail() == null
                    ? "" : loggedInUser.getEmail());

    txtPhone.setText(
            loggedInUser.getPhoneNumber() == null
                    ? "" : loggedInUser.getPhoneNumber());
}


    // Upload a photo, open the crop editor, and save the crop.
    private void choosePhoto() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Choose Profile Photo");

        chooser.setFileFilter(
                new FileNameExtensionFilter(
                        "Image files (JPG, PNG, GIF)",
                        "jpg", "jpeg", "png", "gif"));

        if (chooser.showOpenDialog(this)
                != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File file = chooser.getSelectedFile();

        try {
            BufferedImage image = ImageIO.read(file);

            if (image == null) {
                throw new IllegalArgumentException(
                        "Please choose a valid image file.");
            }

            // Open the crop editor.
            PhotoCropDialog cropDialog =
                    new PhotoCropDialog(this, image);

            cropDialog.setVisible(true);

            BufferedImage croppedImage =
                    cropDialog.getCroppedImage();

            // Do nothing if the user cancels cropping.
            if (croppedImage == null) {
                return;
            }

            Path folder = Paths.get("profile_photos");
            Files.createDirectories(folder);

            Path destination = folder.resolve(
                    "user_" + loggedInUser.getUserId() + ".png");

            if (!ImageIO.write(
                    croppedImage, "png", destination.toFile())) {
                throw new IllegalStateException(
                        "Could not save the cropped image.");
            }

            selectedPhotoPath =
                    destination.toAbsolutePath().toString();

            showPhoto(croppedImage);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(
                    this,
                    "Unable to crop or save photo:\n"
                            + ex.getMessage(),
                    "Photo Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadPhotoPreview() {
        if (selectedPhotoPath == null
                || selectedPhotoPath.trim().isEmpty()) {
            lblPhoto.setIcon(null);
            lblPhoto.setText("No Photo");
            return;
        }

        try {
            BufferedImage image =
                    ImageIO.read(new File(selectedPhotoPath));

            if (image != null) {
                showPhoto(image);
            } else {
                lblPhoto.setIcon(null);
                lblPhoto.setText("Photo unavailable");
            }

        } catch (Exception e) {
            lblPhoto.setIcon(null);
            lblPhoto.setText("Photo unavailable");
        }
    }

    // Display the cropped image as a circular preview.
    private void showPhoto(BufferedImage image) {
        if (image == null) {
            return;
        }

        int size = 120;

        BufferedImage circle = new BufferedImage(
                size, size, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g2 = circle.createGraphics();

        g2.setRenderingHint(
                RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        g2.setRenderingHint(
                RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BICUBIC);

        g2.setClip(new Ellipse2D.Float(0, 0, size, size));

        int width = image.getWidth();
        int height = image.getHeight();

        double scale = Math.max(
                (double) size / width,
                (double) size / height);

        int newWidth = (int) Math.ceil(width * scale);
        int newHeight = (int) Math.ceil(height * scale);

        int x = (size - newWidth) / 2;
        int y = (size - newHeight) / 2;

        g2.drawImage(
                image, x, y, newWidth, newHeight, null);

        g2.dispose();

        lblPhoto.setText("");
        lblPhoto.setIcon(new ImageIcon(circle));
    }

    private void saveProfile() {
        String firstName = txtFirstName.getText().trim();
        String lastName = txtLastName.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhone.getText().trim();

        if (firstName.isEmpty() || lastName.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "First name and last name are required.",
                    "Validation",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        loggedInUser.setFirstName(firstName);
        loggedInUser.setLastName(lastName);
        loggedInUser.setEmail(email.isEmpty() ? null : email);
        loggedInUser.setPhoneNumber(phone.isEmpty() ? null : phone);
        loggedInUser.setProfilePhoto(selectedPhotoPath);

        if (userDAO.updateUser(loggedInUser)) {
            JOptionPane.showMessageDialog(
                    this,
                    "Profile updated successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } else {
            JOptionPane.showMessageDialog(
                    this,
                    "Could not update profile. Check the database connection.",
                    "Update Failed",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
