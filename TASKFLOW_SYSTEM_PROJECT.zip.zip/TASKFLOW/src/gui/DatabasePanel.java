/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */


package gui;

import database.DBConnection;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class DatabasePanel extends JPanel {

    private JLabel lblConnectionStatus;
    private JComboBox<String> cmbTables;
    private JTable tblRecords;
    private DefaultTableModel tableModel;

    private JButton btnTestConnection;
    private JButton btnRefresh;
    private JButton btnViewTable;

    private final String[] expectedTables = {
        "users",
        "member",
        "projects",
        "project_member",
        "task"
    };

    public DatabasePanel() {
        buildDatabaseUI();
        checkDatabaseConnection(false);
        loadDatabaseTables(false);
    }

    // Build the database interface
    private void buildDatabaseUI() {

        setLayout(new BorderLayout(15, 15));
        setBackground(new Color(245, 248, 252));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel lblTitle = new JLabel(
                "DATABASE MANAGEMENT",
                SwingConstants.LEFT
        );

        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(new Color(23, 59, 108));

        lblConnectionStatus = new JLabel(
                "Connection Status: Checking..."
        );
        lblConnectionStatus.setFont(
                new Font("Segoe UI", Font.PLAIN, 14)
        );

        cmbTables = new JComboBox<>();
        cmbTables.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbTables.setPreferredSize(new Dimension(180, 32));

        btnTestConnection = new JButton("TEST CONNECTION");
        btnRefresh = new JButton("REFRESH");
        btnViewTable = new JButton("VIEW TABLE");

        styleButton(btnTestConnection);
        styleButton(btnRefresh);
        styleButton(btnViewTable);

        JPanel headerPanel = new JPanel(
                new BorderLayout(5, 10)
        );
        headerPanel.setOpaque(false);
        headerPanel.add(lblTitle, BorderLayout.NORTH);
        headerPanel.add(lblConnectionStatus, BorderLayout.CENTER);

        JPanel controlPanel = new JPanel(
                new FlowLayout(FlowLayout.LEFT, 10, 10)
        );
        controlPanel.setOpaque(false);
        controlPanel.add(new JLabel("Select Database Table:"));
        controlPanel.add(cmbTables);
        controlPanel.add(btnViewTable);
        controlPanel.add(btnRefresh);
        controlPanel.add(btnTestConnection);

        JPanel northPanel = new JPanel(
                new BorderLayout(5, 10)
        );
        northPanel.setOpaque(false);
        northPanel.add(headerPanel, BorderLayout.NORTH);
        northPanel.add(controlPanel, BorderLayout.SOUTH);

        tableModel = new DefaultTableModel() {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblRecords = new JTable(tableModel);
        tblRecords.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tblRecords.setRowHeight(25);
       tblRecords.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
tblRecords.setFillsViewportHeight(true);

        tblRecords.getTableHeader().setFont(
                new Font("Segoe UI", Font.BOLD, 13)
        );

        JScrollPane scrollPane = new JScrollPane(tblRecords);
        scrollPane.setBorder(
                BorderFactory.createLineBorder(
                        new Color(220, 226, 235)
                )
        );

        add(northPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);

        // Test Connection button
        btnTestConnection.addActionListener(e -> {
            checkDatabaseConnection(true);
        });

        // Refresh button
        btnRefresh.addActionListener(e -> {
            checkDatabaseConnection(false);
            loadDatabaseTables(true);
        });

        // View Table button
        btnViewTable.addActionListener(e -> {
            viewSelectedTable();
        });
        
        // Automatically display records when a table is selected
cmbTables.addActionListener(e -> {
    if (cmbTables.getSelectedItem() != null) {
        viewSelectedTable();
    }
});
    }

    // Style buttons
    private void styleButton(JButton button) {
        button.setFont(new Font("Segoe UI", Font.BOLD, 12));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(23, 59, 108));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(150, 34));
    }

    // Check the MySQL connection
    private void checkDatabaseConnection(boolean showMessage) {

        try (Connection connection = DBConnection.getConnection()) {

            if (connection != null && connection.isValid(3)) {

                lblConnectionStatus.setText(
                        "Connection Status: Connected to taskflow_db"
                );
                lblConnectionStatus.setForeground(
                        new Color(24, 130, 70)
                );

                if (showMessage) {
                    JOptionPane.showMessageDialog(
                            this,
                            "Successfully connected to taskflow_db!",
                            "Connection Successful",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }

            } else {
                showConnectionFailed(showMessage);
            }

        } catch (SQLException e) {

            showConnectionFailed(showMessage);

            if (showMessage) {
                JOptionPane.showMessageDialog(
                        this,
                        "Unable to connect to MySQL:\n" + e.getMessage(),
                        "Database Connection Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }

    private void showConnectionFailed(boolean showMessage) {
        lblConnectionStatus.setText(
                "Connection Status: Disconnected"
        );
        lblConnectionStatus.setForeground(Color.RED);
    }

    // Load available TASKFLOW tables
    private void loadDatabaseTables(boolean showMessage) {

        String previouslySelected =
                (String) cmbTables.getSelectedItem();

        cmbTables.removeAllItems();

        try (Connection connection = DBConnection.getConnection()) {

            DatabaseMetaData metaData = connection.getMetaData();

            for (String tableName : expectedTables) {

                try (ResultSet rs = metaData.getTables(
                        connection.getCatalog(),
                        null,
                        tableName,
                        new String[]{"TABLE"})) {

                    if (rs.next()) {
                        cmbTables.addItem(tableName);
                    }
                }
            }

            if (previouslySelected != null) {
                cmbTables.setSelectedItem(previouslySelected);
            }

            if (cmbTables.getItemCount() == 0) {

                tableModel.setRowCount(0);
                tableModel.setColumnCount(0);

                if (showMessage) {
                    JOptionPane.showMessageDialog(
                            this,
                            "No TASKFLOW tables were found in taskflow_db.\n"
                            + "Check your database and table names.",
                            "Tables Not Found",
                            JOptionPane.WARNING_MESSAGE
                    );
                }

            } else if (showMessage) {

                // Reload records from the selected table
                viewSelectedTable();

                JOptionPane.showMessageDialog(
                        this,
                        "Database tables refreshed successfully.",
                        "Refresh Complete",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }

        } catch (SQLException e) {

            if (showMessage) {
                JOptionPane.showMessageDialog(
                        this,
                        "Unable to load database tables:\n" + e.getMessage(),
                        "Database Error",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        }
    }

    // Display records from the selected table
    private void viewSelectedTable() {

        String tableName =
                (String) cmbTables.getSelectedItem();

        if (tableName == null) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please select a database table first.",
                    "No Table Selected",
                    JOptionPane.WARNING_MESSAGE
            );
            return;
        }

        boolean allowed = false;

        for (String allowedTable : expectedTables) {
            if (allowedTable.equals(tableName)) {
                allowed = true;
                break;
            }
        }

        if (!allowed) {
            JOptionPane.showMessageDialog(
                    this,
                    "Invalid table selection.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return;
        }

        tableModel.setRowCount(0);
        tableModel.setColumnCount(0);

        String sql = "SELECT * FROM `" + tableName + "` LIMIT 500";

        try (Connection connection = DBConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery(sql)) {

            int columnCount = rs.getMetaData().getColumnCount();

            for (int i = 1; i <= columnCount; i++) {
                tableModel.addColumn(
                        rs.getMetaData().getColumnLabel(i)
                );
            }

            while (rs.next()) {

                Object[] row = new Object[columnCount];

                for (int i = 1; i <= columnCount; i++) {
                    row[i - 1] = rs.getObject(i);
                }

                tableModel.addRow(row);
            }

            if (tableModel.getRowCount() == 0) {
                JOptionPane.showMessageDialog(
                        this,
                        "The selected table contains no records.",
                        "No Records",
                        JOptionPane.INFORMATION_MESSAGE
                );
            }

        } catch (SQLException e) {

            JOptionPane.showMessageDialog(
                    this,
                    "Unable to display table records:\n" + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }




    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        contentPanel4 = new javax.swing.JPanel();

        contentPanel4.setBackground(new java.awt.Color(245, 248, 252));
        contentPanel4.setPreferredSize(new java.awt.Dimension(1000, 780));

        javax.swing.GroupLayout contentPanel4Layout = new javax.swing.GroupLayout(contentPanel4);
        contentPanel4.setLayout(contentPanel4Layout);
        contentPanel4Layout.setHorizontalGroup(
            contentPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1290, Short.MAX_VALUE)
        );
        contentPanel4Layout.setVerticalGroup(
            contentPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 752, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contentPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 1290, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contentPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, 752, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel contentPanel4;
    // End of variables declaration//GEN-END:variables
}
