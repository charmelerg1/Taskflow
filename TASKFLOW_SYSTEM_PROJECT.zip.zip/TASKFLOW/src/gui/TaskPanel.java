/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package gui;

import dao.TaskDAO;
import dao.ProjectDAO;
import database.DBConnection;
import model.Task;
import model.Project;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.RowFilter;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

public class TaskPanel extends JPanel {

    private final TaskDAO taskDAO = new TaskDAO();

    private JTable tblTasks;
    private DefaultTableModel tableModel;
    private TableRowSorter<DefaultTableModel> sorter;

    private JTextField txtSearch;
    private JComboBox<String> cmbStatusFilter;
    private JLabel lblTotalTasks;
    private JLabel lblMessage;

    private final Color NAVY = new Color(23, 59, 108);
    private final Color BLUE = new Color(45, 101, 163);
    private final Color BG = new Color(245, 248, 252);
    private final Color WHITE = Color.WHITE;

    public TaskPanel() {
        setLayout(new BorderLayout(15, 15));
        setBackground(BG);
        setBorder(BorderFactory.createEmptyBorder(22, 22, 22, 22));

        createInterface();
        loadTasks();
    }

    private void createInterface() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel title = new JLabel("TASK MANAGEMENT");
        title.setFont(new Font("Segoe UI", Font.BOLD, 27));
        title.setForeground(NAVY);

        lblTotalTasks = new JLabel("Total Tasks: 0");
        lblTotalTasks.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotalTasks.setForeground(BLUE);

        header.add(title, BorderLayout.NORTH);
        header.add(lblTotalTasks, BorderLayout.SOUTH);

        JPanel top = new JPanel(new BorderLayout(10, 10));
        top.setOpaque(false);

        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setPreferredSize(new Dimension(260, 38));
        txtSearch.setToolTipText("Search task name or description");

        cmbStatusFilter = new JComboBox<>(new String[]{
            "All Status", "Pending", "In Progress", "Completed"
        });
        cmbStatusFilter.setFont(new Font("Segoe UI", Font.PLAIN, 13));

        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filters.setOpaque(false);
        filters.add(new JLabel("Search:"));
        filters.add(txtSearch);
        filters.add(new JLabel("Status:"));
        filters.add(cmbStatusFilter);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.setOpaque(false);

        JButton btnAdd = createButton("+ Add Task", BLUE);
        JButton btnEdit = createButton("Edit", NAVY);
        JButton btnDelete = createButton("Delete", new Color(180, 55, 55));

        actions.add(btnAdd);
        actions.add(btnEdit);
        actions.add(btnDelete);

        top.add(filters, BorderLayout.CENTER);
        top.add(actions, BorderLayout.SOUTH);

        String[] columns = {
            "ID", "Task Name", "Project", "Assigned To",
            "Priority", "Deadline", "Status"
        };

        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblTasks = new JTable(tableModel);
        tblTasks.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tblTasks.setRowHeight(32);
        tblTasks.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tblTasks.getTableHeader().setFont(
                new Font("Segoe UI", Font.BOLD, 13));
        tblTasks.getTableHeader().setBackground(NAVY);
        tblTasks.getTableHeader().setForeground(WHITE);
        tblTasks.setAutoCreateRowSorter(true);

        sorter = (TableRowSorter<DefaultTableModel>) tblTasks.getRowSorter();

        JScrollPane scrollPane = new JScrollPane(tblTasks);
        scrollPane.setBorder(BorderFactory.createLineBorder(
                new Color(220, 226, 235)));

        lblMessage = new JLabel(" ");
        lblMessage.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblMessage.setForeground(BLUE);

        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setOpaque(false);
        bottom.add(lblMessage, BorderLayout.CENTER);

        JPanel center = new JPanel(new BorderLayout(10, 10));
        center.setOpaque(false);
        center.add(top, BorderLayout.NORTH);
        center.add(scrollPane, BorderLayout.CENTER);
        center.add(bottom, BorderLayout.SOUTH);

        add(header, BorderLayout.NORTH);
        add(center, BorderLayout.CENTER);

        txtSearch.getDocument().addDocumentListener(
                new javax.swing.event.DocumentListener() {
            public void insertUpdate(javax.swing.event.DocumentEvent e) {
                applyFilters();
            }

            public void removeUpdate(javax.swing.event.DocumentEvent e) {
                applyFilters();
            }

            public void changedUpdate(javax.swing.event.DocumentEvent e) {
                applyFilters();
            }
        });

        cmbStatusFilter.addActionListener(e -> applyFilters());
        btnAdd.addActionListener(e -> showTaskDialog(null));
        btnEdit.addActionListener(e -> editSelectedTask());
        btnDelete.addActionListener(e -> deleteSelectedTask());
    }

    private JButton createButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(WHITE);
        button.setBackground(color);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        button.setPreferredSize(new Dimension(115, 36));
        return button;
    }

    private void loadTasks() {
        tableModel.setRowCount(0);

        List<Task> tasks = taskDAO.getAllTasks();

        for (Task task : tasks) {
            tableModel.addRow(new Object[]{
                task.getTaskId(),
                task.getTaskName(),
                getProjectName(task.getProjectId()),
                getMemberName(task.getAssignedTo()),
                task.getPriority(),
                task.getDeadline() == null
                        ? "" : task.getDeadline().toString(),
                task.getStatus()
            });
        }

        lblTotalTasks.setText("Total Tasks: " + tasks.size());
        applyFilters();
    }

    private String getProjectName(int projectId) {
        if (projectId <= 0) {
            return "Unassigned";
        }

        String sql = "SELECT project_name FROM projects WHERE project_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, projectId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("project_name");
                }
            }

        } catch (SQLException e) {
            System.err.println("Error loading project name: "
                    + e.getMessage());
        }

        return "Unknown Project";
    }

    private String getMemberName(int memberId) {
        if (memberId <= 0) {
            return "Unassigned";
        }

        String sql = "SELECT full_name FROM member WHERE member_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, memberId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("full_name");
                }
            }

        } catch (SQLException e) {
            System.err.println("Error loading member name: "
                    + e.getMessage());
        }

        return "Unknown Member";
    }

    private void applyFilters() {
        if (sorter == null) {
            return;
        }

        List<RowFilter<Object, Object>> filters = new ArrayList<>();

        String search = txtSearch.getText().trim();

        if (!search.isEmpty()) {
            filters.add(RowFilter.regexFilter(
                    "(?i)" + java.util.regex.Pattern.quote(search),
                    1, 2, 3));
        }

        String status = (String) cmbStatusFilter.getSelectedItem();

        if (status != null && !"All Status".equals(status)) {
            filters.add(RowFilter.regexFilter(
                    "^" + java.util.regex.Pattern.quote(status) + "$", 6));
        }

        sorter.setRowFilter(filters.isEmpty()
                ? null : RowFilter.andFilter(filters));
    }

    private void showTaskDialog(Task existingTask) {
        JTextField txtName = new JTextField();
        JTextArea txtDescription = new JTextArea(3, 20);
        txtDescription.setLineWrap(true);
        txtDescription.setWrapStyleWord(true);

        JComboBox<ProjectOption> cmbProject = new JComboBox<>();
        JComboBox<MemberOption> cmbMember = new JComboBox<>();

        JComboBox<String> cmbPriority = new JComboBox<>(
                new String[]{"Low", "Medium", "High"});

        JTextField txtDeadline = new JTextField();

        JComboBox<String> cmbStatus = new JComboBox<>(
                new String[]{"Pending", "In Progress", "Completed"});

        loadProjectsIntoCombo(cmbProject);
        loadMembersIntoCombo(cmbMember);

        if (existingTask != null) {
            txtName.setText(existingTask.getTaskName());
            txtDescription.setText(existingTask.getDescription());
            txtDeadline.setText(existingTask.getDeadline() == null
                    ? "" : existingTask.getDeadline().toString());

            cmbPriority.setSelectedItem(existingTask.getPriority());
            cmbStatus.setSelectedItem(existingTask.getStatus());

            selectProject(cmbProject, existingTask.getProjectId());
            selectMember(cmbMember, existingTask.getAssignedTo());
        }

        JPanel form = new JPanel(new GridLayout(0, 1, 5, 5));
        form.setPreferredSize(new Dimension(380, 440));

        form.add(new JLabel("Task Name *"));
        form.add(txtName);
        form.add(new JLabel("Description"));
        form.add(new JScrollPane(txtDescription));
        form.add(new JLabel("Project"));
        form.add(cmbProject);
        form.add(new JLabel("Assign to Team Member"));
        form.add(cmbMember);
        form.add(new JLabel("Priority *"));
        form.add(cmbPriority);
        form.add(new JLabel("Deadline (YYYY-MM-DD) *"));
        form.add(txtDeadline);
        form.add(new JLabel("Status"));
        form.add(cmbStatus);

        int result = JOptionPane.showConfirmDialog(
                this,
                form,
                existingTask == null ? "Add Task" : "Edit Task",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);

        if (result != JOptionPane.OK_OPTION) {
            return;
        }

        String name = txtName.getText().trim();
        String description = txtDescription.getText().trim();
        String deadlineText = txtDeadline.getText().trim();

        if (name.isEmpty() || deadlineText.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter the task name and deadline.",
                    "Missing Information",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        LocalDate deadline;

        try {
            deadline = LocalDate.parse(deadlineText);
        } catch (DateTimeParseException e) {
            JOptionPane.showMessageDialog(this,
                    "Use the date format YYYY-MM-DD, for example 2026-10-20.",
                    "Invalid Deadline",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        ProjectOption project =
                (ProjectOption) cmbProject.getSelectedItem();

        MemberOption member =
                (MemberOption) cmbMember.getSelectedItem();

        int projectId = project == null ? 0 : project.id;
        int memberId = member == null ? 0 : member.id;

        Task task = new Task(
                existingTask == null ? 0 : existingTask.getTaskId(),
                projectId,
                name,
                description,
                memberId,
                (String) cmbPriority.getSelectedItem(),
                deadline,
                (String) cmbStatus.getSelectedItem()
        );

        boolean success = existingTask == null
                ? taskDAO.addTask(task)
                : taskDAO.updateTask(task);

        if (success) {
            lblMessage.setText(existingTask == null
                    ? "Task added successfully."
                    : "Task updated successfully.");
            loadTasks();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Unable to save the task. Check the NetBeans Output "
                    + "window for database errors.",
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadProjectsIntoCombo(JComboBox<ProjectOption> combo) {
        combo.removeAllItems();
        combo.addItem(new ProjectOption(0, "Unassigned"));

        String sql = "SELECT project_id, project_name FROM projects "
                + "ORDER BY project_name";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                combo.addItem(new ProjectOption(
                        rs.getInt("project_id"),
                        rs.getString("project_name")));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Unable to load projects: " + e.getMessage());
        }
    }

    private void loadMembersIntoCombo(JComboBox<MemberOption> combo) {
        combo.removeAllItems();
        combo.addItem(new MemberOption(0, "Unassigned"));

        String sql = "SELECT member_id, full_name FROM member "
                + "ORDER BY full_name";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                combo.addItem(new MemberOption(
                        rs.getInt("member_id"),
                        rs.getString("full_name")));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Unable to load team members: " + e.getMessage());
        }
    }

    private void selectProject(JComboBox<ProjectOption> combo, int id) {
        for (int i = 0; i < combo.getItemCount(); i++) {
            if (combo.getItemAt(i).id == id) {
                combo.setSelectedIndex(i);
                return;
            }
        }
    }

    private void selectMember(JComboBox<MemberOption> combo, int id) {
        for (int i = 0; i < combo.getItemCount(); i++) {
            if (combo.getItemAt(i).id == id) {
                combo.setSelectedIndex(i);
                return;
            }
        }
    }

    private void editSelectedTask() {
        int row = tblTasks.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this,
                    "Please select a task to edit.");
            return;
        }

        int modelRow = tblTasks.convertRowIndexToModel(row);
        int taskId = (int) tableModel.getValueAt(modelRow, 0);

        Task task = taskDAO.getTaskById(taskId);

        if (task != null) {
            showTaskDialog(task);
        }
    }

    private void deleteSelectedTask() {
        int row = tblTasks.getSelectedRow();

        if (row == -1) {
            JOptionPane.showMessageDialog(this,
                    "Please select a task to delete.");
            return;
        }

        int modelRow = tblTasks.convertRowIndexToModel(row);
        int taskId = (int) tableModel.getValueAt(modelRow, 0);

        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to delete this task?",
                "Confirm Delete",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (taskDAO.deleteTask(taskId)) {
                lblMessage.setText("Task deleted successfully.");
                loadTasks();
            } else {
                JOptionPane.showMessageDialog(this,
                        "Unable to delete task. Check the database error.");
            }
        }
    }

    private static class ProjectOption {
        int id;
        String name;

        ProjectOption(int id, String name) {
            this.id = id;
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    private static class MemberOption {
        int id;
        String name;

        MemberOption(int id, String name) {
            this.id = id;
            this.name = name;
        }

        @Override
        public String toString() {
            return name;
        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        contentPanel4 = new javax.swing.JPanel();

        contentPanel4.setBackground(new java.awt.Color(245, 248, 252));
        contentPanel4.setPreferredSize(new java.awt.Dimension(1000, 780));

        javax.swing.GroupLayout contentPanel4Layout = new javax.swing.GroupLayout(contentPanel4);
        contentPanel4.setLayout(contentPanel4Layout);
        contentPanel4Layout.setHorizontalGroup(
            contentPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1290, Short.MAX_VALUE)
        );
        contentPanel4Layout.setVerticalGroup(
            contentPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 763, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contentPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, 1290, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contentPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, 763, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel contentPanel4;
    // End of variables declaration//GEN-END:variables
}
