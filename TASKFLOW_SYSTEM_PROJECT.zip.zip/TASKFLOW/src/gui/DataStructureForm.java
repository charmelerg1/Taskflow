/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package gui;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;


public class DataStructureForm extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(DataStructureForm.class.getName());
    
     private ArrayList<model.Task> taskList = new ArrayList<>();

    // Queue for upcoming tasks
    private Queue<model.Task> taskQueue =
            new LinkedList<>();

    // Stack for completed tasks
    private Stack<model.Task> completedStack =
            new Stack<>();

    /**
     * Creates new form DataStructureForm
     */
    public DataStructureForm() {
        initComponents();
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitle = new javax.swing.JLabel();
        btnLoadTasks = new javax.swing.JButton();
        btnSearch = new javax.swing.JButton();
        btnSort = new javax.swing.JButton();
        lblSearch = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        lblArrayList = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblArrayList = new javax.swing.JTable();
        lblQueue = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        listQueue = new javax.swing.JList<>();
        lblStack = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        listStack = new javax.swing.JList<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        lblTitle.setBackground(new java.awt.Color(23, 59, 108));
        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 28)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(23, 59, 108));
        lblTitle.setText(" TASKFLOW DATA STRUCTURES");

        btnLoadTasks.setText("LOAD TASKS");
        btnLoadTasks.addActionListener(this::btnLoadTasksActionPerformed);

        btnSearch.setText("SEARCH");

        btnSort.setText("SORT");

        lblSearch.setText("Search:");

        lblArrayList.setText("ALL TASKS");

        tblArrayList.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "ID", "Task Name", "Priority", "Status"
            }
        ));
        jScrollPane1.setViewportView(tblArrayList);

        lblQueue.setText("UPCOMING TASKS");

        listQueue.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Task 1", "Task 2", "Task 3" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(listQueue);

        lblStack.setText("COMPLETED TASKS");

        listStack.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Task 3", "Task 2", "Task 1" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(listStack);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(213, 213, 213)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTitle)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(lblQueue))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(lblStack)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lblArrayList)
                                    .addGap(0, 0, Short.MAX_VALUE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(lblSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(btnLoadTasks, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btnSort, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(22, 22, 22))
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 505, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(282, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addComponent(lblTitle)
                .addGap(66, 66, 66)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSort)
                    .addComponent(btnSearch)
                    .addComponent(btnLoadTasks)
                    .addComponent(lblSearch)
                    .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addComponent(lblArrayList)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblQueue)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(lblStack)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(56, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnLoadTasksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLoadTasksActionPerformed
   

      // Clear the data structures
    taskList.clear();
    taskQueue.clear();
    completedStack.clear();

    // Get tasks from database
    dao.TaskDAO taskDAO = new dao.TaskDAO();

    taskList.addAll(taskDAO.getAllTasks());

    // ==========================================
    // ARRAYLIST - ALL TASKS
    // ==========================================

    javax.swing.table.DefaultTableModel tableModel =
            (javax.swing.table.DefaultTableModel)
            tblArrayList.getModel();

    tableModel.setRowCount(0);

    for (model.Task task : taskList) {

        tableModel.addRow(new Object[]{
            task.getTaskId(),
            task.getTaskName(),
            task.getPriority(),
            task.getStatus()
        });

        // ==========================================
        // QUEUE - PENDING TASKS
        // ==========================================

        if ("Pending".equalsIgnoreCase(task.getStatus())) {
            taskQueue.offer(task);
        }

        // ==========================================
        // STACK - COMPLETED TASKS
        // ==========================================

        if ("Completed".equalsIgnoreCase(task.getStatus())) {
            completedStack.push(task);
        }
    }

    // ==========================================
    // DISPLAY QUEUE
    // ==========================================

    javax.swing.DefaultListModel<String> queueModel =
            new javax.swing.DefaultListModel<>();

    for (model.Task task : taskQueue) {

        queueModel.addElement(
                task.getTaskId() + " - " +
                task.getTaskName()
        );
    }

    listQueue.setModel(queueModel);

    // ==========================================
    // DISPLAY STACK
    // ==========================================

    javax.swing.DefaultListModel<String> stackModel =
            new javax.swing.DefaultListModel<>();

    for (model.Task task : completedStack) {

        stackModel.addElement(
                task.getTaskId() + " - " +
                task.getTaskName()
        );
    }

    listStack.setModel(stackModel);

    javax.swing.JOptionPane.showMessageDialog(
            this,
            "Tasks loaded successfully!"
    );

    }//GEN-LAST:event_btnLoadTasksActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new DataStructureForm().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnLoadTasks;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnSort;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblArrayList;
    private javax.swing.JLabel lblQueue;
    private javax.swing.JLabel lblSearch;
    private javax.swing.JLabel lblStack;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JList<String> listQueue;
    private javax.swing.JList<String> listStack;
    private javax.swing.JTable tblArrayList;
    private javax.swing.JTextField txtSearch;
    // End of variables declaration//GEN-END:variables
}
