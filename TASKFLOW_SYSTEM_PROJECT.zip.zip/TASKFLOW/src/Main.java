import database.DBConnection;
import java.sql.Connection;

public class Main {

    public static void main(String[] args) {

        System.out.println("Testing TASKFLOW database connection...");

        Connection conn = DBConnection.getConnection();

        if (conn != null) {
            System.out.println("Connection test PASSED!");
        } else {
            System.out.println("Connection test FAILED!");
        }
    }
}